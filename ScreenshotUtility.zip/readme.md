Go to Tools->Screenshot to open the window. 

Preferences:
--------------------
Go to Edit->Preferences->Screenshot tab. This can also be through the gear button at the top-right. 

It's recommend to check this out, as an important option is presented!

Notes:
-----------------------
• Settings are saved in the operating system's registry, on a per-project basis.
• The "Print-screen button" option only takes effect if the window is open and the scene-view has focus