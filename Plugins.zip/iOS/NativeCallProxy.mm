//
//  NativeCallProxy.m
//  LILPOP
//
//  Created by 정건우 on 2022/01/10.
//
#import <Foundation/Foundation.h>
#import "NativeCallProxy.h"

@implementation FrameworkLibAPI

id<NativeCallsProtocol> api = NULL;
+(void) registerAPIforNativeCalls:(id<NativeCallsProtocol>) aApi
{
    api = aApi;
}

@end

extern "C"
{
    void unityToIos(const char* message)
    {
        return [api unityToIos:[NSString stringWithUTF8String:message]];
    }
}
