//
//  NativeCallProxy.h
//  LILPOP
//
//  Created by 정건우 on 2022/01/10.
//

#ifndef NativeCallProxy_h
#define NativeCallProxy_h


#endif /* NativeCallProxy_h */
#import <Foundation/Foundation.h>

@protocol NativeCallsProtocol
@required
- (void) unityToIos:(NSString*)message;
// other methods
@end

__attribute__ ((visibility("default")))
@interface FrameworkLibAPI : NSObject
+(void) registerAPIforNativeCalls:(id<NativeCallsProtocol>) aApi;

@end
