using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class LotteryMGR : MonoBehaviour
{
    public LotteryData LotteryData;
    public WebSocketConnect webSocketConnect;
    public Image picture;
    public string pictureURL;
    public Text nick, introduce, timer;
    public GameObject notiOBJ;
    public Image applyBTN;
    public Sprite[] applySprite;
    public bool timeout = true;
    TimeSpan timeSpan;
        DateTime myDate;
        DateTime now;
    Coroutine timerRT, apiRT, loadRT;
    public void NotiMessage()
    {
        if (LotteryData.apply)
        {
            notiOBJ.SetActive(true);
            Invoke("ExitNoti", 2f);
        }
        else
        {
            LotteryData.apply = true;
            applyBTN.sprite = applySprite[1];
            StartCoroutine(ApplyLottery());
        }
    }
    void ExitNoti()
    {
        notiOBJ.SetActive(false);
    }
    private void Start()
    {
        loadRT = StartCoroutine(LoadIMG());
    }
    public void OpenLottery()
    {
        timeout = true;
        this.StopAllCoroutines();
            
        loadRT = StartCoroutine(LoadIMG());
    }
    IEnumerator UpdateTimer()
    {
      
        now = DateTime.Now;
        timeSpan = now - myDate;

        float min = Mathf.Floor(timeSpan.Seconds / 60);
        float sec = Mathf.RoundToInt(timeSpan.Seconds % 60);
        if (Mathf.Abs((float)timeSpan.TotalSeconds) < 0.5 && !timeout)
        {
           // Debug.Log("timeout");
            timeout = true;
            StopCoroutine(timerRT);
            StopCoroutine(apiRT);
            StopCoroutine(loadRT);
            yield return new WaitForSeconds(0.5f);
            loadRT = StartCoroutine(LoadIMG());
        }
        else if (Mathf.Abs((float)timeSpan.TotalSeconds) >= 0.5)
        {
//            Debug.Log("count");
            timer.text = string.Format(Mathf.Abs(timeSpan.Minutes).ToString("00") + ":" + Mathf.Abs(timeSpan.Seconds).ToString("00"));
            yield return new WaitForSeconds(0.5f);
            timerRT = StartCoroutine(UpdateTimer());
        }
       
    }
    IEnumerator ApplyLottery()
    {
        string url;
        string value = webSocketConnect.responeseLogin.access_token;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/lottery";///" + webSocketConnect.responeseLogin.id;
        }
        else
        {
            url = "https://api.lilpop.kr/v1/lottery";// + webSocketConnect.responeseLogin.id;
        }

        string json;
        LooteryApply LooteryApplyData = new LooteryApply();
        LooteryApplyData.user_id = webSocketConnect.responeseLogin.id;
        LooteryApplyData.item_id = LotteryData.item_id;
        json = JsonUtility.ToJson(LooteryApplyData);
   
        using (UnityWebRequest request = UnityWebRequest.Post(url, json))
        {
            byte[] jsonToSend = new System.Text.UTF8Encoding().GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(jsonToSend);
            request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
            request.SetRequestHeader("Authorization", "Bearer " + value);
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();
            if (request.isNetworkError || request.isHttpError)
            {
                Debug.Log(request.error);
            }
         
        }
    }
    IEnumerator PictureLoad()
    {
        if (timeout)
        {
            //Debug.Log("api ㅇㅛㅊㅓㅇ");
            string value = webSocketConnect.responeseLogin.access_token;
            string url;
            if (webSocketConnect.testMode)
            {
                url = "https://dev.lilpop.kr/api/v1/lottery/" + webSocketConnect.responeseLogin.id;
            }
            else
            {
                url = "https://api.lilpop.kr/v1/lottery/" + webSocketConnect.responeseLogin.id;
            }
            UnityWebRequest www = UnityWebRequest.Get(url);
            www.SetRequestHeader("Authorization", "Bearer " + value);

            yield return www.SendWebRequest();

            if (www.isNetworkError || www.isHttpError)
            {
               // Debug.Log(www.error);
                yield return new WaitForSeconds(0.1f);
               apiRT = StartCoroutine(PictureLoad());
            }
            else
            {
                LotteryData = JsonConvert.DeserializeObject<LotteryData>(www.downloadHandler.text);
                if (LotteryData.image.Length > 1)
                {
                    pictureURL = LotteryData.image;
                }
                timeout = false;
                myDate = Convert.ToDateTime(LotteryData.lottery_time);
                loadRT = StartCoroutine(LoadIMG());
            }
        }
        else
        {
            loadRT = StartCoroutine(LoadIMG());
        }
    }
    IEnumerator LoadIMG()
    {

        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        if (pictureURL.Length > 0 && !timeout)
        {
            UnityWebRequest www = UnityWebRequestTexture.GetTexture(pictureURL);
            yield return www.SendWebRequest();
            Texture2D texture = ((DownloadHandlerTexture)www.downloadHandler).texture;
            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2());
//            Debug.Log(www.error);
            picture.sprite = sprite;
            nick.text = LotteryData.artist_name;

            if (!LotteryData.apply)
            {
                applyBTN.sprite = applySprite[0];
            }
            else
            {
                applyBTN.sprite = applySprite[1];
            }
          timerRT =  StartCoroutine(UpdateTimer());
        }
        else
        {
          apiRT =  StartCoroutine(PictureLoad());
        }
    }
}
[System.Serializable]
public class LotteryData
{
    public int code;
    public string message;
    public string lottery_time;
    public bool apply;
    public string item_id;
    public string item_name;
    public string item_level;
    public string artist_id;
    public string artist_name;
    public string description;
    public string image;
}
public class LooteryApply
{
    public string user_id;
    public string item_id;
}

