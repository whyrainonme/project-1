using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DG.Tweening;
using MyDefines.Enum;
using UnityEngine;
using UnityEngine.SocialPlatforms;
using UnityEngine.UI;
using static SitAnim;
using static UnityEngine.UIElements.UxmlAttributeDescription;

public class UsersMove : MonoBehaviour
{
    public Vector3 pos;
    public string dir;
    public int charactorNum = 0;
    float speed = 3f;
    public Text userID;
    public Image gender;
    public EnteredUsers enteredUsers;
    public GameObject user_canvas;
    WebSocketConnect webSocketConnect;
    public GameObject chatBox;
    public Text chatText;
    public string chatString;
    public string state;
    public float jumpPower, jumpSpeed;
    public bool isJumping;
    public GameObject headIcon;
    CharactorSettings charactorSettings;
    public Sprite[] currWalks;
    public GameObject enterEffect, voiceEffect;
    public bool voiceState;
    public bool sitState;
    public GameObject sitPosOBJ;
    Animator animator;
    PlayerAnim playerAnim;
    private void Start()
    {
        playerAnim = GetComponent<PlayerAnim>();
        animator = GetComponent<Animator>();
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        charactorSettings = GameObject.Find("CharactorDB").GetComponent<CharactorSettings>();
        if (enteredUsers.etc.sit == "down")
        {
            sitState = true;
        }
        StartCoroutine(chatMessage());
    }
   
    public SpriteRenderer render;
   
    Vector3 currPos;
    public void Jump(string jumptype)
    {
        if (isJumping) return;
        else
        {
            isJumping = true;
            currPos = transform.position;
            transform.position = currPos;
            animator.SetTrigger("JUMP");
            this.gameObject.GetComponent<Rigidbody2D>().gravityScale = 1;
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector3(0, jumpPower, 0));
            StartCoroutine(Jump1(jumptype));
        }
    }
 
    IEnumerator Jump1(string dir)
    {
     
        yield return new WaitForSeconds(0.4f);
        for (int i = 0; i < webSocketConnect.recvMove.users.Count; i++)
        {
            if (webSocketConnect.recvMove.users[i].id == gameObject.name)
            {
                webSocketConnect.recvMove.users[i].action = null;
                webSocketConnect.recvMove.users[i].vector3 = currPos;
            }
        }
       
        this.gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
        transform.position = currPos;
        isJumping = false;
    }
    public void EmojiAction(int num)
    {
        StartCoroutine(ActionEmote(num));
    }
   
    IEnumerator ActionEmote(int num)
    {
        CharactorSettings db = GameObject.Find("CharactorDB").GetComponent<CharactorSettings>();
        GameObject emote = Instantiate(db.emoticons[num], transform.Find("UsersCanvas"));
        emote.GetComponent<RectTransform>().sizeDelta = new Vector2(0.6f, 0.6f);
        Debug.Log(emote.GetComponent<RectTransform>().anchoredPosition);
        emote.GetComponent<RectTransform>().DOAnchorPosY(0.8f, 1f).From(new Vector2(0.7f,0.9f)* 0.2f);
        for (int i = 0; i < webSocketConnect.recvMove.users.Count; i++)
        {
            if (webSocketConnect.recvMove.users[i].id == gameObject.name)
            {
                webSocketConnect.recvMove.users[i].action = null;
                webSocketConnect.recvMove.users[i].vector3 = currPos;
            }
        }
        yield return new WaitForSeconds(2f);
        Destroy(emote);
    }
    IEnumerator chatMessage()
    {
      
        if (chatString != "" && webSocketConnect.area == state)
        {
          
            chatText.text = chatString;
            chatBox.SetActive(true);
            yield return new WaitForSeconds(3f);
            
            chatBox.SetActive(false);
            chatString = "";
            StartCoroutine(chatMessage());
        }
        else
        {
            yield return new WaitForSeconds(0.2f);
            StartCoroutine(chatMessage());
        }
    }
    public void UserInfo()
    {
        var metaverse = new MI_Metaverse();
        metaverse.SendUserInfo(gameObject.name);
    }
    private void FixedUpdate()
    {
     
        if (webSocketConnect.exitUser.id == this.gameObject.name)
        {
            Destroy(this.gameObject);

            for (int i = 0; i < webSocketConnect.rcevUserEnter.users.Count; i++)
            {
                if (webSocketConnect.rcevUserEnter.users[i].id == this.gameObject.name)
                {
                    webSocketConnect.rcevUserEnter.users.RemoveAt(i);
                }
            }
            webSocketConnect.exitUser.id = "";
            webSocketConnect.exitUser.cmd = "";
            webSocketConnect.exitUser.map = "";
            StopAllCoroutines();
            return;
        }
        playerAnim.SpriteSheetName = enteredUsers.appearance.character_id;
        userID.text = enteredUsers.profile.nickname;
        if (enteredUsers.profile.user_type == "artist") { headIcon.SetActive(true); }
        else { headIcon.SetActive(false); }
        if (webSocketConnect.area == state && state != "")
        {
            if (voiceState)
            {
                userID.color = new Vector4(1f, 0.5f, 1f, 1f);
                voiceEffect.SetActive(true);
                animator.SetTrigger("TALK");
            }
            else
            {
                userID.color = new Vector4(1f, 1f, 1f, 1f);
                voiceEffect.SetActive(false);
            }
        }
        else
        {
            userID.color = new Vector4(1f, 1f, 1f, 1f);
            enterEffect.SetActive(false);
            voiceEffect.SetActive(false);
        }
        if (!isJumping)
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
            Vector3.Distance(gameObject.transform.position, pos);
            if (Vector3.Distance(gameObject.transform.position, pos) >= 3f)
            {
                transform.position = pos;
            }
            else
            {
                transform.position = Vector3.MoveTowards(gameObject.transform.position, pos, speed * Time.deltaTime);

            }
            switch (dir)
            {
                case "FL":
                    render.flipX = false;
                    animator.SetFloat("Blend", 0);
                    break;
                case "BR":
                    render.flipX = false;
                    animator.SetFloat("Blend", 1);
                    break;
                case "BL":
                    render.flipX = true;
                    animator.SetFloat("Blend", 1);
                    break;
                case "FR":
                    render.flipX = true;
                    animator.SetFloat("Blend", 0);
                    break;
            }
            Vector3 movAmount = pos - transform.position;
            if (movAmount.x > 0f || movAmount.x < 0f || movAmount.y < 0f || movAmount.y > 0f)
            {
                animator.SetBool("WALK", true);
            }
            else
            {
                animator.SetBool("WALK", false);
            }
        }
    }
    public float moveAnimSpeed = 0.2f;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AudioZone")
        { 
            state = collision.gameObject.name;
            enterEffect.SetActive(true);
        }
    }
    public void SitDownAnim()
    {
        rotateDir r = sitPosOBJ.GetComponent<SitAnim>().r;
        dir = r.ToString();
        animator.SetBool("SIT", true);
    }
    public void SitUpAnim()
    {
        animator.SetBool("SIT", false);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AudioZone")
        {
            enterEffect.SetActive(false);
            voiceEffect.SetActive(false);
            state = "";
        }
    
    }
    public void DestroySelf()
    {
        Destroy(this.gameObject);
    }
}
