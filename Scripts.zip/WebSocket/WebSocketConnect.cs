using UnityEngine.UI;
using UnityEngine.SceneManagement;
using WebSocketSharp;
using System.Collections.Concurrent;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;

public class WebSocketConnect : MonoBehaviour

{
    public bool DebugLog = false;
    public bool isLoading = false;
    public bool checkInit = false;
    public LoginRequest loginData;
    public bool testMode = false;
    public bool EditorMode = false;
    public bool effectSound = true;
    public ChangeAppearance changeAppearance;
    public string language;
    public bool micState;
    public ChatList chatList;
    public Notice noticeData;
    public RcevMapInfo rcevMapInfo;
    public ResponeseLogin responeseLogin;
    public bool socketState;
    //[System.NonSerialized]
    public int prevEnterCnt = 0, currEnterCnt = 0;
    public GameObject playerPrefab;
    public RecvMove recvMove;
    public RcevUserEnter rcevUserEnter;
    public UserExit exitUser;
    private WebSocket m_WebSocket;
    [System.NonSerialized]
    public string tokenID = null;
    public string websocketURL;
    public string sceneName = null;
    public string area = null;
    public string chatMessage = null;
    static public WebSocketConnect Instance;
    public List<EnteredUsers> Users;
    private void OnApplicationPause(bool pause)
    {
        if (!pause && selectCharactor.selectedChar)
        {
            StartCoroutine(RequestToken());
        }
    }
 
    public void InitEnterData()
    {
        chatList.cmd = "";
        chatList.map = "";
        chatList.chat.Clear();
        area = "";

        rcevUserEnter.cmd = "";
        rcevUserEnter.count = 0;
        rcevUserEnter.map = "";
        rcevUserEnter.users.Clear();

        rcevMapInfo = null;

        
        recvMove.cmd = "";
        recvMove.map = "";
        recvMove.users.Clear();
    }
    public void DestroyUserOBJ()
    {
        var users = GameObject.FindGameObjectsWithTag("users");

        for (int i = 0; i < users.Length; i++)
        {
            Destroy(users[i]);
        }
    }
    private void Awake()
    {
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        sceneName = SceneType();
          // playerPrefab = Resources.Load<GameObject>("Prefabs/User") as GameObject;
        if (Instance != null)
        {
            Destroy(this.gameObject);
           
        }
        else
        {
            DontDestroyOnLoad(this.gameObject);
            Instance = this;
        }
        if (EditorMode)
        {
            StartCoroutine(LoadToken());
        }
    }
    IEnumerator LoadToken()
    {
        string json = JsonUtility.ToJson(loginData);
        string url;
        url = "https://dev.lilpop.kr/api/v1/auth/login";
        using (UnityWebRequest request = UnityWebRequest.Post(url, json))
        {
            byte[] jsonToSend = new System.Text.UTF8Encoding().GetBytes(json);
            request.uploadHandler = new UploadHandlerRaw(jsonToSend);
            request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");

            yield return request.SendWebRequest();
            if (request.isNetworkError || request.isHttpError)
            {
                Debug.Log(request.error);
            }
            else
            {
                string jsonString = request.downloadHandler.text;
                var response = JsonUtility.FromJson<LoginResponse>(jsonString);
                responeseLogin.access_token = response.access_token;
                responeseLogin.id = response.id;
                request.Dispose();
               
            }


        }
    }
    IEnumerator WebSocketMessage()
    {
        //Debug.Log("WebSocketMessage");
        yield return new WaitForSeconds(0.2f);
        m_WebSocket.OnMessage += (sender, e) =>
        {
            if(DebugLog) Debug.Log($"{((WebSocket)sender).Url}에서 + 데이터 : {e.Data}가 옴.");
          
            var data = JsonConvert.DeserializeObject<StringData>(e.Data).cmd;
            if (data == "notice")
            {
                noticeData = JsonUtility.FromJson<Notice>(e.Data);
            }
            if (data == "map_info")
            {
                rcevMapInfo = JsonUtility.FromJson<RcevMapInfo>(e.Data); 
            }
            if (data == "success" && SceneType() != "MyROOM" + responeseLogin.id)
            {
                MapInfo mapInfo = new MapInfo();
                mapInfo.cmd = "map_info";
                mapInfo.id = responeseLogin.id;
                mapInfo.map = sceneName;
                string json = JsonUtility.ToJson(mapInfo);
                m_WebSocket.Send(json); 
            }
            if (data == "enter")
            {
                var RcevUserEnterData = JsonUtility.FromJson<RcevUserEnter>(e.Data); 
                if (RcevUserEnterData.map == sceneName)
                {
                    if (RcevUserEnterData.users.Count != 0)
                    {
                        rcevUserEnter.cmd = RcevUserEnterData.cmd;
                        rcevUserEnter.count = RcevUserEnterData.count;
                        rcevUserEnter.curr_user = RcevUserEnterData.curr_user;
                        rcevUserEnter.max_user = RcevUserEnterData.max_user;
                        rcevUserEnter.map = RcevUserEnterData.map;
                        for (int i = 0; i < RcevUserEnterData.users.Count; i++)
                        {
                            rcevUserEnter.users.Add(RcevUserEnterData.users[i]);
                        }
                    }
                    else
                    {
                        rcevUserEnter = RcevUserEnterData;
                    }
                }
            }
            if (data == "chat")
            {
                var chatData = JsonUtility.FromJson<ChatList>(e.Data);
                chatList = chatData;
            }
            if (data == "move_action")
            {
                var RcevUserMoveData = JsonUtility.FromJson<RecvMove>(e.Data);
                recvMove.users = RcevUserMoveData.users;
            }
            if (data == "exit")
            {
                exitUser = JsonUtility.FromJson<UserExit>(e.Data);
            }
            if (data == "appearance")
            {
                changeAppearance = JsonUtility.FromJson<ChangeAppearance>(e.Data);
            }

        };
        StartCoroutine(countTime(0.2f));
    }
    public void StartWebsocket()
    {
        Application.runInBackground = true;
        StartCoroutine(RequestToken());
    }
    void Update()//IEnumerator void UserObjedcts()
    {

        if (effectSound)
        {
            var audio = GameObject.FindObjectsOfType<AudioSource>();
            for (int i = 0; i< audio.Length; i++)
            {
                audio[i].volume = 1;
            }
        }
        else
        {
            var audio = GameObject.FindObjectsOfType<AudioSource>();
            for (int i = 0; i < audio.Length; i++)
            {
                audio[i].volume =0;
            }
        }

        if (changeAppearance.id != "" && changeAppearance.id != responeseLogin.id)
        {
            GameObject.Find(changeAppearance.id).GetComponent<UsersMove>().enteredUsers.appearance = changeAppearance.appearance;
            GameObject.Find(changeAppearance.id).GetComponent<UsersMove>().enteredUsers.profile.nickname = changeAppearance.nickname;
            changeAppearance.id = "";
        }
        else if (changeAppearance.id == responeseLogin.id)
        {
            responeseLogin.nickname = changeAppearance.nickname;
            changeAppearance.id = "";
        }

        MoveUsers();

        for (int i = 0; i < rcevUserEnter.users.Count; i++)
        {
            if (!GameObject.Find(rcevUserEnter.users[i].id) && exitUser.id != rcevUserEnter.users[i].id && rcevUserEnter.map == sceneName)
            {
                Vector3 pos = rcevUserEnter.users[i].vector3;
                GameObject users = GameObject.Instantiate<GameObject>(playerPrefab, pos, Quaternion.identity);
                users.name = rcevUserEnter.users[i].id;
                users.GetComponent<UsersMove>().pos = pos;
                users.GetComponent<UsersMove>().enteredUsers = rcevUserEnter.users[i];
                users.GetComponent<UsersMove>().charactorNum = Int32.Parse(rcevUserEnter.users[i].appearance.character_id);
              
            }
          
        }
    }
   
    void MoveUsers()
    {
        for (int i = 0; i < recvMove.users.Count; i++)
        {
            if (recvMove.users[i].id != responeseLogin.id) //자기자신이 아닌 경우
            {
                
                if (GameObject.Find(recvMove.users[i].id))
                {
                    GameObject moveUser = GameObject.Find(recvMove.users[i].id).gameObject;
                   
                    if (recvMove.users[i].action != null && recvMove.users[i].action.type == "sit")
                    {
                        moveUser.GetComponent<UsersMove>().pos = (recvMove.users[i].action.vector3);
                        moveUser.GetComponent<UsersMove>().dir = (recvMove.users[i].dir);
                        if (recvMove.users[i].action.value == "up")
                        {
                            moveUser.GetComponent<UsersMove>().sitState = false;
                            moveUser.GetComponent<UsersMove>().SitUpAnim();
                           // moveUser.GetComponent<UsersMove>().pos = moveUser.GetComponent<UsersMove>().pos;
                        }
                        else
                        {
                            moveUser.GetComponent<UsersMove>().sitState = true;
                            moveUser.GetComponent<UsersMove>().SitDownAnim();
                        }
                        //                        recvMove.users[i].action = null;
                       
                    }
                    else if (recvMove.users[i].action != null && recvMove.users[i].action.type == "jump")
                    {
                       
                        Vector3 pos = moveUser.GetComponent<UsersMove>().pos;
                        recvMove.users[i].vector3 = pos;
                        moveUser.GetComponent<UsersMove>().Jump(recvMove.users[i].action.value);
                    }
                    else if(recvMove.users[i].action != null && recvMove.users[i].action.type == "emoji")
                    {
                        if (recvMove.users[i].dir == null || recvMove.users[i].vector3 == null)
                        {
                            Vector3 pos = moveUser.GetComponent<UsersMove>().pos;
                            string dir = moveUser.GetComponent<UsersMove>().dir;
                            moveUser.GetComponent<UsersMove>().pos = pos;
                            moveUser.GetComponent<UsersMove>().dir = dir;
                        }
                        moveUser.GetComponent<UsersMove>().EmojiAction(Int32.Parse(recvMove.users[i].action.value));

                    }
                    else if (recvMove.users[i].action != null && recvMove.users[i].action.type == "voice")
                    {
                        if (recvMove.users[i].dir == null || recvMove.users[i].vector3 == null)
                        {
                            Vector3 pos = moveUser.GetComponent<UsersMove>().pos;
                            string dir = moveUser.GetComponent<UsersMove>().dir;
                            moveUser.GetComponent<UsersMove>().pos = pos;
                            moveUser.GetComponent<UsersMove>().dir = dir;
                        }
                        if (recvMove.users[i].action.value == "start")
                        {
                            moveUser.GetComponent<UsersMove>().voiceState = true;
                        }
                        else
                        {
                            moveUser.GetComponent<UsersMove>().voiceState = false;

                        }
                        // recvMove.users[i].action = null;
                    }
                    else
                    {
                        moveUser.GetComponent<UsersMove>().pos = (recvMove.users[i].vector3);
                        moveUser.GetComponent<UsersMove>().dir = (recvMove.users[i].dir);
                    }

                    
                }
            }
        }
    }
 
    IEnumerator countTime(float delayTime)
    {

        if (GameManager.Instance.isMove && m_WebSocket.ReadyState == WebSocketState.Open && !isLoading && selectCharactor.selectedChar)
        {
            sendMessage(1);
        }
   
        yield return new WaitForSeconds(delayTime);
        StartCoroutine(countTime(0.2f));
    }
    IEnumerator Login()
    {
        if (m_WebSocket == null ||
            m_WebSocket.ReadyState != WebSocketState.Open)
        {
            m_WebSocket = new WebSocket(websocketURL);
            m_WebSocket.SslConfiguration.EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12;
            m_WebSocket.Connect();
        }
        yield return new WaitForSeconds(0.2f);
        StartCoroutine(WebSocketMessage());
        if (m_WebSocket == null)
        {
            yield return null;
        }
        if (!isLoading && m_WebSocket.ReadyState == WebSocketState.Open || selectCharactor.selectedChar)
        {
            string json;
            UserLogin login = new UserLogin();
            login.cmd = "login";
            login.id = responeseLogin.id;
            login.access_token = responeseLogin.access_token;
            json = JsonUtility.ToJson(login);
            m_WebSocket.Send(json);
            yield return new WaitForSeconds(0.2f);
            sendMessage(0);
        }
        StartCoroutine(ConnectStateCheck());
    }
    public CharSelected CharSelected;
    public SelectCharactor selectCharactor;
    public void sendMessage(int status)
    {
        //Debug.Log("sendMessage");
        if (m_WebSocket.ReadyState != WebSocketState.Open || isLoading || !selectCharactor.selectedChar)
        {
            return;
        }
        else
        {
            GameObject player = GameObject.Find("Player");
            Vector3 pos = player.transform.position;
            string dir = player.GetComponent<PlayerMove>().CurrentDir.ToString();
            string json;
            //Android에서 받아온 데이터로 수정하기
            switch (status)
            {
                case 0: // enter
                        //초기 엔터시에는 등록된 캐릭터 외형정보 불러오기
                    SendUserEnter enter = new SendUserEnter();
                    enter.cmd = "enter";
                    enter.id = responeseLogin.id;
                    enter.map = SceneType();

                    //등록된 외형받아오기
                    //LoadCharSet(enter);
                    Appearance appearance = new Appearance();
                    appearance.character_id = GameObject.Find("Player").GetComponent<PlayerAnim>().SpriteSheetName;
                    appearance.skin_color = GameObject.Find("Player").GetComponent<PlayerAnim>().SpriteSheetName;
                    appearance.hair = "1";
                    appearance.face = "2";
                    appearance.top = "3";
                    appearance.pants = "4";
                    appearance.shoes = "5";
                    appearance.hand_item = "4";
                    appearance.face_item = "4";
                    appearance.etc = "5";

                    enter.appearance = appearance;
                    enter.vector3 = pos;
                    //if (SceneType() == "MyROOM" + responeseLogin.id)
                    //{
                    //    //enter.myroom = true;
                    //}
                    json = JsonUtility.ToJson(enter);
                    m_WebSocket.Send(json);
                    sendMessage(3);
                    break;
                case 1: // move my position
                    SendMove move = new SendMove();
                    move.cmd = "move";
                    move.id = responeseLogin.id;
                    move.map = SceneType();
                    move.dir = dir;
                    move.vector3 = pos;
                    json = JsonUtility.ToJson(move);
                    m_WebSocket.Send(json);
                    break;
                case 2: // exit (Change Map)
                    UserExit exit = new UserExit();
                    exit.cmd = "exit";
                    exit.id = responeseLogin.id;
                    exit.map = SceneType();
                    if (SceneType() == "MyROOM" + responeseLogin.id)
                    {
                        exit.myroom = true;
                    }
                    json = JsonUtility.ToJson(exit);
                    m_WebSocket.Send(json);
                    InitEnterData();
                    break;
                case 3: // map_info (Change Map)
                    MapInfo mapInfo = new MapInfo();
                    mapInfo.cmd = "map_info";
                    mapInfo.id = responeseLogin.id;
                    mapInfo.map = SceneType();
                    json = JsonUtility.ToJson(mapInfo);
                    m_WebSocket.Send(json);
                    break;
                case 4: // chat
                    ChatSend chat = new ChatSend();
                    chat.cmd = "chat";
                    chat.id = responeseLogin.id;
                    chat.map = SceneType();
                    chat.area = area;
                    chat.message = chatMessage;
                    chatMessage = null;
                    json = JsonUtility.ToJson(chat);
                    m_WebSocket.Send(json);
                    break;
                case 5:
                    ChangeAppearance changeAPR = new ChangeAppearance();
                    changeAPR.cmd = "appearance";
                    changeAPR.id = responeseLogin.id;
                    changeAPR.nickname = responeseLogin.nickname;
                    changeAPR.map = SceneType();
                    Appearance appear = new Appearance();
                    appear.character_id = GameObject.Find("Player").GetComponent<PlayerAnim>().SpriteSheetName;
                    appear.skin_color = GameObject.Find("Player").GetComponent<PlayerAnim>().SpriteSheetName;
                    appear.hair = "1";
                    appear.face = "2";
                    appear.top = "3";
                    appear.pants = "4";
                    appear.shoes = "5";
                    appear.hand_item = "4";
                    appear.face_item = "4";
                    appear.etc = "5";
                    changeAPR.appearance = appear;
                    json = JsonUtility.ToJson(changeAPR);
                    m_WebSocket.Send(json);
                    //Debug.Log(json);
                    break;
                default:
                    return;
            }
        }
    }
    public void SendPosition(Vector3 pos, string dir)
    {
        if (m_WebSocket.ReadyState != WebSocketState.Open || isLoading || !selectCharactor.selectedChar)
        {
            return;
        }
        else
        {
            string json;
            SendMove move = new SendMove();
            move.cmd = "move";
            move.id = responeseLogin.id;
            move.map = sceneName;
            move.dir = dir;
            move.vector3 = pos;
            json = JsonUtility.ToJson(move);
            m_WebSocket.Send(json);
        }
    }
    public void SendActionMessage(string type, string value, Vector3 pos)
    {
        if (m_WebSocket.ReadyState != WebSocketState.Open || isLoading || !selectCharactor.selectedChar)
        {
            return;
        }
        else
        {
            string json;
            var actions = new SendActions();
            actions.cmd = "action";
            actions.id = responeseLogin.id;
            actions.map = sceneName;
            
            var action = new Actions();
            action.type = type;
            action.value = value;

            action.vector3 = pos;
            actions.action = action;
            json = JsonUtility.ToJson(actions);
            m_WebSocket.Send(json);
        }
    }
    public string SceneType()
    {
        switch (SceneManager.GetActiveScene().buildIndex)
        {
            case 0:
                sceneName = "GANGNAM-COEX";
                break;
            case 1:
                sceneName = "HONGDAE-SANGSANG";
                break;
            case 2:
                sceneName = "GANGNAM-COEX-WILDWILD-TOWN";
                break;
            case 3:
                sceneName = "GANGNAM-COEX-WILDWILD-FAN";
                break;
            case 4:
                sceneName = "HONGDAE";
                break;
            case 5:
                sceneName = "GANGNAM-COEX-HOME-1";
                break;
            case 6:
                sceneName = "GANGNAM-COEX-PLAYGROUND";
                break;
            case 7:
                sceneName = "GANGNAM-COEX-WILDWILD-LIMOUSINE"; //partyroom
                break;
            case 8:
                sceneName = "GANGNAM-COEX-WILDWILD-FAN-ROOM-1";
                break;
            case 9:
                sceneName = "MYROOM:" + responeseLogin.id;
                break;
            case 10:
                sceneName = "GANGNAM-COEX-DRINKLINE";
                break;
            case 11:
                sceneName = "GANGNAM-COEX-KLAMBLOOD";
                break;
            case 12:
                sceneName = "GANGNAM-COEX-NEMOPLANET";
                break;
            case 13:
                sceneName = "GANGNAM-COEX-ODC";
                break;
            case 14:
                sceneName = "GANGNAM-COEX-MISUN";
                break;
            case 15:
                sceneName = "GANGNAM-COEX-ZAR";
                break;

        }
        
        return sceneName;
    }
    void OnApplicationQuit()
    {
        DisconnectWebsocket();
    }
    IEnumerator ConnectStateCheck()
    {
        if (m_WebSocket.ReadyState == WebSocketState.Closed ||
            m_WebSocket.ReadyState == WebSocketState.Closing ||
            m_WebSocket.ReadyState != WebSocketState.Open)
        {
            socketState = false;
        }
        else
        {
            socketState = true;
        }
      
        if (socketState == false && !isLoading)
        {
            StartCoroutine(RequestToken());
        }
        else
        {
            yield return new WaitForSeconds(5f);
            StartCoroutine(ConnectStateCheck());
        }
    }
    
            
    bool disconnect = false;
    public void DisconnectWebsocket()
    {

        if (m_WebSocket == null)
            return;

        disconnect = true;
        UserExit exit = new UserExit();
        exit.cmd = "exit";
        exit.id = responeseLogin.id;
        string json = JsonUtility.ToJson(exit);
        m_WebSocket.Send(json);
        if (m_WebSocket.IsAlive)
            m_WebSocket.Close();
        StopAllCoroutines();

    }
    public IEnumerator RequestToken()
    {
        if (responeseLogin.access_token != null && responeseLogin.access_token != "" && !isLoading && selectCharactor.selectedChar)
        {
            StopAllCoroutines();
            StartCoroutine(LoadWebsocketData());
        }
        else
        {
            yield return new WaitForSeconds(0.2f);
            StartCoroutine(RequestToken());
        }
    }

    IEnumerator LoadWebsocketData()
    {
        
        string value = responeseLogin.access_token;
        string url;
        if (testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/metaverse/server?map=" + SceneType();
        }
        else
        {
            url = "https://api.lilpop.kr/v1/metaverse/server?map=" + SceneType();
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);
        yield return www.SendWebRequest();
        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.01f);
        }
        else
        {
            var Data = JsonConvert.DeserializeObject<WebSocketInfo>(www.downloadHandler.text);
            if(Data.message == "success")
            {
                websocketURL = Data.address;
            }
            else
            {
                yield return new WaitForSeconds(0.01f);
                StartCoroutine(LoadWebsocketData());
            }
            yield return new WaitForSeconds(0.1f);
            if (websocketURL != "" && websocketURL != null)
            {
                StartCoroutine(Login());
            }
            else
            {
                StartCoroutine(LoadWebsocketData());
            }
        }
    }
}
[System.Serializable]
public class WebSocketInfo
{
    public int code;
    public string message;
    public string address;
    public int max_user;
    public int curr_user;
}
[System.Serializable]
public class MapInfo
{
    public string cmd;
    public string id;
    public string map;
}
[System.Serializable]
public class RcevMapInfo
{
    public string code;
    public string message;
    public string cmd;
    public string map;
    public Video[] video;
    public Audio[] audio;
    public Texts[] text;
}
[System.Serializable]
public class Video
{
    public string id;
    public string value;
}
[System.Serializable]
public class Audio
{
    public string id;
    public string value;
}
[System.Serializable]
public class Texts
{
    public string id;
    public string value;
}
[System.Serializable]
public class SendUserEnter //유저가 들어갈때 서버에 보낼 데이터
{
    public string cmd;
    public string id;
    public string map;
    //public Profile profile;
    public Appearance appearance;
    public Vector3 vector3;
    //public bool myroom;
}
[System.Serializable]
public class ChangeAppearance //외형변경시 받을 데이터 
{
    public string cmd;
    public string id;
    public string nickname;
    public string map;
    public Appearance appearance;
}
[System.Serializable]
public class RcevUserEnter //유저가 들어갈때 서버에서 받을 데이
{
    public string cmd;
    public string map;
    public int max_user;
    public int curr_user;
    public int count;
    public List<EnteredUsers> users;
}
[System.Serializable]
public class EnteredUsers //접속되어있는 유저들의 데이
{
    public string id;
    public Profile profile;
    public Appearance appearance;
    public Vector3 vector3;
    public etc etc;
    public bool myroom;
}
[System.Serializable]
public class etc
{
    public string dir;
    public string sit;
}
[System.Serializable]
public class Appearance
{
    public string character_id;
    public string skin_color;
    public string hair;
    public string face;
    public string top;
    public string pants;
    public string shoes;
    public string hand_item;
    public string face_item;
    public string hat;
    public string etc;
}
[System.Serializable]
public class CharSelected
{
    public string user_id;
    public string character;
    public bool set_main;
    public string skin_color;
    public string hair;
    public string face;
    public string top;
    public string pants;
    public string shoes;
    public string hand_item;
    public string face_item;
    public string hat;
    public string etc;
}

[System.Serializable]
public class Profile
{
    public string nickname;
    public string user_type;
    public string gender;
    public string picture;
}
[System.Serializable]
public class LoginRequest
{
    public string id;
    public string auth_type;
    public string password;
}
[System.Serializable]
public class LoginResponse
{
    public string code;
    public string message;
    public string id;
    public string access_token;
    public string access_expires_in;
    public string refresh_expires_in;
}
[System.Serializable]
public class ResponeseLogin
{
    public string access_token;
    public string cmd;
    public string id;
    public string uuid;
    public string nickname;
    public string user_type;
    public string gender;
    public string picture;
}
[System.Serializable]
public class UserList
{
    public GameObject userOBJ;
    public string userID;
}
[System.Serializable]
public class ChatSend
{
    public string cmd;
    public string id;
    public string map;
    public string area;
    public string message;
}
[System.Serializable]
public class ChatList
{
    public string cmd;
    public string map;
    public List<Chat> chat;
}
[System.Serializable]
public class Chat
{
    public string id;
    public string nickname;
    public string area;
    public string message;
}
[System.Serializable]
public class Notice
{
    public string cmd;
    public int duration;
    public string text_color;
    public string text;
    public string[] target_id;
}
