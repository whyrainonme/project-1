using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class SendMove
{
    public string cmd;
    public string id;
    public string map;
    public string dir;
    public Vector3 vector3;
}
[System.Serializable]
public class Users
{
    public string id;
    public string dir;
    public Vector3 vector3;
    public Actions action;
}
[System.Serializable]
public class Actions
{
    public string type;
    public string value;
    public Vector3 vector3;
}
[System.Serializable]
public class SendActions
{
    public string cmd;
    public string id;
    public string map;
    public Actions action;
}
[System.Serializable]
public class RecvMove
{
    public string cmd;
    public string map;
    public List<Users> users;
}


[System.Serializable]
public class UserExit {
    public string cmd;
    public string id;
    public string map;
    public bool myroom;
}
[System.Serializable]
public class UserLogin
{
    public string cmd;
    public string id;
    public string access_token;
}
public class StringData
{
    public string cmd;
    public string message;
}
public class WebSocketClient : MonoBehaviour
{ }