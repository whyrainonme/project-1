using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Video;

public class VidesoLoad : MonoBehaviour
{
    VideoPlayer videoPlayer;
   public string videourl, videoID, videoName;
    string[] split_text;
    Camera cam;
    WebSocketConnect webSocketConnect;
    // Start is called before the first frame update
    void Start()
    {
        cam = GameObject.Find("Player").transform.Find("Main Camera").GetComponent<Camera>();
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        videoPlayer = GetComponent<VideoPlayer>();
        StartCoroutine(PlayVideo());
    }
    bool bPaused;
   
    private void Update()
    {
        if (!videoPlayer.isPlaying && CheckObjectInCamera())
        {
            videoPlayer.Play();
        }
        else if (videoPlayer.isPlaying && !CheckObjectInCamera())
        {
            videoPlayer.Pause();
        }

    }
    bool CheckObjectInCamera()
    {
        Vector3 point = cam.WorldToViewportPoint(transform.position);
        bool onScreen = point.z > 0 && point.x > 0 && point.x < 1 && point.y > 0 && point.y < 1;
        return onScreen;
    }
  
    IEnumerator PlayVideo()
    {
        yield return new WaitForSeconds(0.2f);
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        if (!webSocketConnect.isLoading)
        {
            if (videourl.Length < 1)
            {
                yield return new WaitForSeconds(0.2f);
                for (int i = 0; i < webSocketConnect.rcevMapInfo.video.Length; i++)
                {
                    if (videoID == webSocketConnect.rcevMapInfo.video[i].id)
                    {
                        videourl = webSocketConnect.rcevMapInfo.video[i].value;
                    }
                }
                StartCoroutine(PlayVideo());
            }
            else
            {
                split_text = videourl.Split('/');
                string name = split_text[split_text.Length - 1];
                if (name != videoName)
                {
                    videoName = name;
                    StartCoroutine(downloadAndPlayVideo(videourl, name, true));
                }
            }
        }
        else
        {
            yield return new WaitForSeconds(0.2f);
            StartCoroutine(PlayVideo());
        }
    }

    IEnumerator downloadAndPlayVideo(string videoUrl, string saveFileName, bool overwriteVideo)
    {
        string saveDir = Path.Combine(Application.persistentDataPath, saveFileName);
        string playbackDir = saveDir;
        bool downloadSuccess = false;
        byte[] vidData = null;
        string[] persistantData = Directory.GetFiles(Application.persistentDataPath);
        if (persistantData.Contains(playbackDir))
        {
            playVideo(playbackDir);
            yield break;
        }
        else
        {
            yield return downloadData(videoUrl, (status, dowloadData) =>
            {
                downloadSuccess = status;
                vidData = dowloadData;
            });
        }
        if (downloadSuccess)
        {
            saveVideoFile(saveDir, vidData);
            playVideo(playbackDir);
        }
      
    }
    IEnumerator downloadData(string videoUrl, Action<bool, byte[]> result)
    {
        UnityWebRequest webRequest = UnityWebRequest.Get(videoUrl);
        webRequest.Send();
        while (!webRequest.isDone)
        {
            yield return null;
        }
        if (webRequest.isNetworkError)
        {
            yield break;
        }
        result(!webRequest.isNetworkError, webRequest.downloadHandler.data);
    }
    bool saveVideoFile(string saveDir, byte[] vidData)
    {
        try
        {
            FileStream stream = new FileStream(saveDir, FileMode.Create);
            stream.Write(vidData, 0, vidData.Length);
            stream.Close();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }

    }
    void playVideo(string path)
    {
        videoPlayer.source = VideoSource.Url;
        videoPlayer.url = path;
        videoPlayer.Prepare();
        while (videoPlayer.isPrepared == false)
        { return; }
        videoPlayer.Play();
    }

}
