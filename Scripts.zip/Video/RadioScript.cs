using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;

public class RadioScript : MonoBehaviour
{
    public GameObject radioCanvas;
    public VideoPlayer videio;
    public AudioSource audio;
    public AudioClip[] sound;
    public SwipeUI swipeUI;
    public void Streaming()
    {
        radioCanvas.SetActive(true);
        StartCoroutine(Radio());
    }
    public void RadioCanvas()
    {
        StartCoroutine(Radio());
    }
    IEnumerator Radio()
    {
        if (!GameManager.Instance.soundData)
        {
            audio.Stop();
        }
        else
        {
            audio.loop = false;
            audio.clip = sound[1];
            audio.Play();
            while (true)
            {
                yield return new WaitForSeconds(0.5f);
                if (!audio.isPlaying)
                {
                    audio.clip = sound[0];
                    audio.Play();
                    audio.loop = true;
                }
            }
        }

       
    }
    public void TVCanvas()
    {
        audio.Stop();
        radioCanvas.SetActive(true);
        swipeUI.SetScrollBarValue(0);
        videio.Play(); //SwipeUI  index =0;
    }
    public void ExitRadio()
    {
        if (videio != null)
        {
            videio.Stop();
            audio.clip = sound[0];
            audio.Play();
            radioCanvas.SetActive(false);
        }
        else
        {
            audio.clip = sound[0];
            audio.Play();
            radioCanvas.SetActive(false);
        }
    
    }
}
