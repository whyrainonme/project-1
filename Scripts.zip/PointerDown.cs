using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PointerDown : MonoBehaviour
{
    public GameObject canvas;
    public GameObject sprites;
    public int num;
  
    public void TouchPicture()
    {
        sprites.SetActive(true);
        canvas.SetActive(true);
    }
    public void CloseCanvas()
    {
        sprites.SetActive(false);
        canvas.SetActive(false);
    }
}
