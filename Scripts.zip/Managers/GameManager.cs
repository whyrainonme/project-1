using System.Collections;
using System.Collections.Generic;
using MyDefines.Enum;
using UnityEngine;

// ?????????? ???????? ??????
public class GameManager : MonoBehaviour
{
    public Vector2 lastPOS = Vector2.zero;
    public bool soundData = true;
    public bool isMove = false;
    private static GameManager sInstance = null;
    public static GameManager Instance
    {
        get
        {
            if (IsApplicationQutting) return null;

            if(sInstance == null)
            {
                sInstance = new GameObject("_GameManager").AddComponent<GameManager>();
                DontDestroyOnLoad(sInstance.gameObject);
            }
           
            return sInstance;
        }
    }
    private static bool IsApplicationQutting = false;

    private void OnDestroy()
    {
        IsApplicationQutting = true;
    }

    #region ===== Managers ======
    private EventManager _event;
    private SceneLoadManager _scene;
    private DBManager _db;
    private ResourceManager _resource;
    private ErrorManager _error;
    public static EventManager Event { get => Instance._event; }
    public static SceneLoadManager Scene { get => Instance._scene; }
    public static DBManager DB { get => Instance._db; }
    public static ResourceManager Resource { get => Instance._resource; }
    public static ErrorManager Error { get => Instance._error; }
    #endregion

    private void Awake()
    {
        Application.backgroundLoadingPriority = ThreadPriority.Low;
        //this.CreateManagers();
    }

    private void CreateManagers()
    {
        _event = new GameObject("_Event").AddComponent<EventManager>();
        _event.transform.SetParent(this.transform);

        _scene = new GameObject("_Scene").AddComponent<SceneLoadManager>();
        _scene.transform.SetParent(this.transform);

        _db = new GameObject("_DB").AddComponent<DBManager>();
        _db.transform.SetParent(this.transform);

        _resource = new GameObject("_Resource").AddComponent<ResourceManager>();
        _resource.transform.SetParent(this.transform);

        _error = new GameObject("_Error").AddComponent<ErrorManager>();
        _error.transform.SetParent(this.transform);
    }
}
