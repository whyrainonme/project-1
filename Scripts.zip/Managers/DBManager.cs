using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;

// ������ ���̽� ����
public class DBManager : MonoBehaviour
{
    public Dictionary<ItemType, int> ItemData { get; private set; }
    private void Awake()
    {
        this.LoadDatas();
    }

    private void Start()
    {
        GameManager.Event.GetItem += AddItem;
    }

    private void LoadDatas()
    {
        ItemData = new Dictionary<ItemType, int>();
    }

    public void AddItem(ItemType type, int number)
    {
        if (ItemData.ContainsKey(type))
            ItemData[type] += number;
        else
        {
            ItemData.Add(type, number);
        }
    }

    public string GetItemString(ItemType type)
    {
        switch (type)
        {
            case ItemType.Bicycle:
                return "������";
            case ItemType.Concert_Ticket:
                return "���� Ƽ��";
            case ItemType.XRated_Potion:
                return "X-Rated ����";
            case ItemType.Max:
            default:
                return "";
        }
    }

    public int GetItemNumber(ItemType type)
    {
        if (ItemData.ContainsKey(type))
            return ItemData[type];
        else
            return 0;
    }
}
