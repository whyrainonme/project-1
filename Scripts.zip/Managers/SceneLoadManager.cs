using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using MyDefines.Enum;
using UnityEngine.Video;

public class SceneLoadManager : MonoBehaviour
{
    
    public bool isLoading { get; private set; } = false;
    public Scene_Type Current_SceneType { get; private set; } = Scene_Type.WolrdMap;
    private float MinimumLoadTime = 2f;
    public GameObject loadingPopup, mapCanvas, player;
     WebSocketConnect webSocketConnect;
    public void SceneLoad(Scene_Type type, string selectMap, Vector3 pos = new Vector3())
    {
        if (isLoading == false)
        {
            mapCanvas.GetComponent<ButtonPanel>().isloading = true;
            mapCanvas.SetActive(false);
            loadingPopup.SetActive(true);
            StartCoroutine(eLoad(type, selectMap, pos));
        }
        else
            return;
    }

    private IEnumerator eLoad(Scene_Type type, string selectMap, Vector3 pos = new Vector3())
    {
        yield return new WaitForSeconds(0.2f);
        MI_Metaverse metaverse = new MI_Metaverse();

        if (selectMap != "miniMap")
        {
            metaverse.SendIconEnable("false");
        }
        GameObject player = GameObject.Find("Player");
        GameObject canvas = player.transform.Find("PlayerCanvas").gameObject;
    

        yield return new WaitForSeconds(0.1f);

        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        webSocketConnect.DestroyUserOBJ();
        webSocketConnect.sendMessage(2);

        
        isLoading = true;
        Scene_Type preSceneType = Current_SceneType;
        if (preSceneType != type)
        {
                webSocketConnect.isLoading = true;
        }
        if (type == Scene_Type.HongDea || type == Scene_Type.WolrdMap)
        {
            Camera.main.orthographicSize = 7f;
        }
        else
        {
            Camera.main.orthographicSize = 4.5f;
        }

        AsyncOperation async = SceneManager.LoadSceneAsync((int)type);
        async.allowSceneActivation = false;
        while (!async.isDone)
        {
            if (async.progress < 0.9f)
            {
                isLoading = true;
            }
            else
            {
                Camera.main.gameObject.transform.parent = player.transform;
                Camera.main.gameObject.transform.localPosition = new Vector3(0, 0, -20f);
                Current_SceneType = type;
                webSocketConnect.InitEnterData();
                yield return new WaitForSeconds(0.3f);
                async.allowSceneActivation = true;
               
                if (player.GetComponent<PlayerEnterArea>().area != "")
                {
                    player.GetComponent<PlayerEnterArea>().ExitWebRTC();
                }
                yield return new WaitForSeconds(0.3f);
                //if (type == Scene_Type.My_Room)
                //{
                //    webSocketConnect.DisconnectWebsocket();
                //    MyRoomWebsocket MyRoomWebsocket = GameObject.Find("MyRoomSocket").GetComponent<MyRoomWebsocket>();
                //    StartCoroutine(MyRoomWebsocket.GetText());
                //}
                mapCanvas.SetActive(true);
                mapCanvas.GetComponent<ButtonPanel>().isloading = false;
                webSocketConnect.sceneName = webSocketConnect.SceneType();
                yield return new WaitForSeconds(0.3f);
                metaverse.SendIconEnable("true");

                webSocketConnect.isLoading = false;
                isLoading = false;
                webSocketConnect.sendMessage(0);
                metaverse.MetaverseMoveMap(webSocketConnect.sceneName);
                SettingBySceneType(type, pos, preSceneType, selectMap);
                canvas.transform.Find("EnterIcon").gameObject.SetActive(false);
                yield return new WaitForSeconds(0.3f);
               
                loadingPopup.SetActive(false);
                yield break;
            }
        }

        yield return null;

    }

    private void SettingBySceneType(Scene_Type type,Vector3 pos, Scene_Type preSceneType,string selectMap)
    {
        if (PlayerMove.Instance != null) PlayerMove.Instance.SetPositionBySceneType(type, pos, preSceneType, selectMap);
    }

}
