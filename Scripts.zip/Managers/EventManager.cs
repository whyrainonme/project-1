using System;
using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;

// ?????? ?????? ???? ????
public class EventManager : MonoBehaviour
{
    private Dictionary<Event_Type, Action> dicEvents;

    public Action<string> SendChat;
    public Action<ItemType, int> GetItem;
    public Action GetPreset;


    private void Awake()
    {
        dicEvents = new Dictionary<Event_Type, Action>();
    }

    public void EventInvoke(Event_Type type)
    {
        if(dicEvents.ContainsKey(type))
        {
            dicEvents[type]();
        }
        else
        {
           // Debug.LogError($"EventManager.{nameof(dicEvents)} is Empty");
            return;
        }
    }

    public void AddEvent(Event_Type type, Action action)
    {
        if(dicEvents.ContainsKey(type))
        {
            dicEvents[type] += action;
            return;
        }
        else
        {
            dicEvents.Add(type, action);
        }
    }

    public void RemoveEvent(Event_Type type, Action action)
    {
        if(dicEvents.ContainsKey(type))
        {
            dicEvents[type] -= action;
        }
        else
        {
           // Debug.LogError($"EventManager.{nameof(dicEvents)} is Empty");
            return;
        }
    }
}
