using UnityEngine;

public class ErrorManager : MonoBehaviour
{
    public ErrorPopup errorPopup;

    public void ErrorMessage(string message)
    {
        errorPopup.Pop(message);
    }
}
