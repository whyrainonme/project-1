using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;
public class ResourceManager : MonoBehaviour
{
    private const string SPRITE_PATH = "Sprites/";
    private Dictionary<SpriteResourceType, Sprite> dicSprites;

    private static T GetResoucre<T>(string path) where T : Object
    {
        return Resources.Load<T>(SPRITE_PATH + path);
    }

    private void Awake()
    {
        dicSprites = new Dictionary<SpriteResourceType, Sprite>();
        this.LoadSpriteFromResources();
    }

    private void LoadSpriteFromResources()
    {
        dicSprites.Add(SpriteResourceType.Item_Peach, GetResoucre<Sprite>("Items/peach"));
        dicSprites.Add(SpriteResourceType.Item_ConcertTicket, GetResoucre<Sprite>("Items/ticket"));
        dicSprites.Add(SpriteResourceType.Item_SaleTicket, GetResoucre<Sprite>("Items/Sale_Ticket"));
        dicSprites.Add(SpriteResourceType.XRated_Potion, GetResoucre<Sprite>("Items/XRated_Potion_TestImage"));
        dicSprites.Add(SpriteResourceType.Bicycle, GetResoucre<Sprite>("Items/Pixel_Bicycle_TestImage"));
    }

    public Sprite GetItemSprite(ItemType type)
    {
        switch (type)
        {
            case ItemType.Bicycle:
                return dicSprites[SpriteResourceType.Bicycle];
            case ItemType.Concert_Ticket:
                return dicSprites[SpriteResourceType.Item_ConcertTicket];
            case ItemType.XRated_Potion:
                return dicSprites[SpriteResourceType.Item_SaleTicket];
            case ItemType.Peach:
                return dicSprites[SpriteResourceType.Item_Peach];
            case ItemType.Max:
            default:
                return null;
        }
    }
}
