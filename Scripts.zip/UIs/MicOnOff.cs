using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MicOnOff : MonoBehaviour
{
    public Sprite micOn, micOff;
    public Image micIMG;
    WebSocketConnect webSocketConnect;
    // Start is called before the first frame update
    void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
    }

    // Update is called once per frame
    public void MicState(bool state)
    {
        if (state)
        {
             micIMG.sprite = micOn;
        }
        else
        {
            micIMG.sprite = micOff;
        }
    }
}
