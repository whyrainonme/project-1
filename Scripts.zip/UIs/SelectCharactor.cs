using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class SelectCharactor : MonoBehaviour
{
    public GameObject initObj;
    public Button prev, next;
    public Sprite MainCharactor;
    public Image charIMG;
    public Text charactorName;
    public Sprite[] sprites;
    string[] names;
    public int index = 0;
    public int rotateState = 0;
    public bool isSpecial = false;
    GameObject player;
    WebSocketConnect webSocketConnect;
    CharactorSettings charactorSettings;
    public ScrollRect scrollRect;
    public RectTransform[] contents;
    public bool selectedChar = false;
    //bool isSpecial = false;
    // public TranslationText translationText;
    public string currName;
    public Button enterBTN;
    public Image[] specailPre;
    private void Awake()
    {
        charIMG.sprite = MainCharactor;
        player = GameObject.Find("Player").gameObject;
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        charactorSettings = GameObject.Find("CharactorDB").GetComponent<CharactorSettings>();
        sprites = new Sprite[charactorSettings.CharactorAnims.Length];
        for (int i = 0; i < charactorSettings.specialPreview.Length; i++)
        {
            specailPre[i].sprite = charactorSettings.specialPreview[i].image;
        }
        //CharName();
       // BasicSkinColor(10);
    }
    public void ContentNum(int num)
    {
        scrollRect.content = contents[num];
       
    }
    void CharName()
    {
        names = new string[charactorSettings.CharactorAnims.Length];
        for (int i = 0; i < names.Length; i++)
        {
            names[i] = charactorSettings.CharactorAnims[i].charName;
        }
        //charactorName.text = names[0];
    }
    public void BasicSkinColor(int num)
    {
        rotateState = 0;
        charIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        isSpecial = false;
        index = num;
        charIMG.sprite = sprites[index];
        charactorName.text = names[num];
    }

    public void SelectedChar(string name)
    {
        //PlayerAnim.enabled = true;
        //charIMG.GetComponent<Animator>().enabled = true;
        enterBTN.interactable = true;
        currName = name;
        for(int i = 0; i < charactorSettings.charactors.Length; i++)
        {
            if(name == charactorSettings.charactors[i].charName)
            {
                charIMG.sprite = charactorSettings.charactors[i].charactor;
            }
        }
        // PlayerAnim.SpriteSheetName = name;
        charactorName.text = name;
    }


    public void NextCharactor()
    {
        switch (rotateState)
        {
            case 0:
                rotateState = 1;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[0];
                charIMG.transform.localScale = new Vector3(-1.2f, 1.2f, 1.2f);
                break;
            case 1:
                rotateState = 2;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[4];
                charIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
                break;
            case 2:
                rotateState = 3;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[4];
                charIMG.transform.localScale = new Vector3(-1.2f, 1.2f, 1.2f);
                break;
            case 3:
                rotateState = 0;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[0];
                charIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
                break;
        }
      
    }
    public void SpecialPreview(int i)
    {
        //PlayerAnim.enabled = false;
        //charIMG.GetComponent<Animator>().enabled = false;
        enterBTN.interactable = false;
        charIMG.sprite = charactorSettings.specialPreview[i].charactor;
        currName = charactorSettings.specialPreview[i].charName;
        //PlayerAnim.SpriteSheetName = name;
        charactorName.text = currName;
    }
    public void PrevCharactor()
    {
        switch (rotateState)
        {
            case 0:
                rotateState = 3;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[4];
                charIMG.transform.localScale = new Vector3(-1.2f, 1.2f, 1.2f);
                break;
            case 1:
                rotateState = 0;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[0];
                charIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
                break;
            case 2:
                rotateState = 1;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[0];
                charIMG.transform.localScale = new Vector3(-1.2f, 1.2f, 1.2f);
                break;
            case 3:
                rotateState = 2;
                charIMG.sprite = charactorSettings.CharactorAnims[index].charactors.walks[4];
                charIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
                break;
        }
    }
   public void CharactorChoice()
    {
        //외형변경 정보 보내기 
        //player.GetComponent<PlayerMove>().render.sprite = sprites[index];
        player.GetComponent<PlayerAnim>().SpriteSheetName = currName;

        if (!selectedChar)
        {
            selectedChar = true;
            webSocketConnect.StartWebsocket();
        }
        else
        {
            webSocketConnect.sendMessage(5);//Appreance Change
        }
    }
    public void IconActivation(bool isActive)
    {
        if (!initObj.activeSelf)
        {
            MI_Metaverse metaverse = new MI_Metaverse();
            if (isActive)
            {
                metaverse.SendIconEnable("true");
            }
            else
            {
                metaverse.SendIconEnable("false");
            }
        }
       
    }
}
