using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectActive : MonoBehaviour
{
    public void ObjecActive(GameObject obj)
    {
        obj.SetActive(true);
    }
    public void ObjecUnActive(GameObject obj)
    {
        obj.SetActive(false);
    }
}
