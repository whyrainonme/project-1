using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;

public class MainCanvas : MonoBehaviour
{
    [SerializeField] private PopupPanel popupPanel;
    private static MainCanvas Instance;
    public CanvasGroup[] buttons;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
            Destroy(this.gameObject);


        //if (GameManager.Instance != null)
        //{
        //    GameManager.UI.PopupActive -= PopupActive;
        //    GameManager.UI.PopupActive += PopupActive; 
        //}
    }

    public void ButtonsCanvasGroup(int num, bool isActive)
    {
        //확정되면 참조제거
        if (isActive)
        {
            buttons[num].interactable = true;
            buttons[num].alpha = 1f;
        }
        else
        {
            buttons[num].interactable = false;
            buttons[num].alpha = 0.5f;
        }
    }

    //private void OnDestroy()
    //{
    //    if (GameManager.Instance != null)
    //    {
    //        GameManager.UI.PopupActive -= PopupActive;
    //    }
    //}

    //public void PopupActive(PopupType type, bool active)
    //{
    //    popupPanel.PoupSetActive(type, active);
    //}
}
