using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TranslationText : MonoBehaviour
{
    WebSocketConnect webSocketConnect;
    string language;
    public string textStr;
    Text text;
    // Start is called before the first frame update
    void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        text = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        language = webSocketConnect.language;
        text.text = Translation(textStr);
      
    }

    public string Translation(string str)
    {
        string result = str;
        switch (language)
        {
            case "EN":
                for (int i = 0; i < strKR.Length; i++)
                {
                    if (result == strKR[i])
                    {
                        result = strEN[i];
                    }
                }
                break;
            case "JP":
                for (int i = 0; i < strKR.Length; i++)
                {
                    if (result == strKR[i])
                    {
                        result = strJP[i];
                    }
                }
                break;
            case "CN":
                for (int i = 0; i < strKR.Length; i++)
                {
                    if (result == strKR[i])
                    {
                        result = strCN[i];
                    }
                }
                break;
            default:
                break;
        }
        return result;
    }
    string[] strKR = {"아바타 선택", "NEXT", "STREET", "첫번째캐릭터", "두번째캐릭터", "세번째캐릭터", "Enter text…", "MAP", "나가기", "Sorry we're not available right now",
        "알림", "KOEX (Gangnam)", "Hongdae","닫기","지역","전체","예상치 못한 버그가 발생했습니다.","이동중입니다" };

    string[] strEN = {"Avatar selection", "NEXT", "STREET", "First character", "Second character", "Third character", "Enter text…", "MAP", "Exit", "申し訳ありませんが、現在ご利用いただけません",
        "Notice", "KOEX (Gangnam)", "Hongdae","close","area","all","An unexpected bug has occurred.","On the move"};

    string[] strJP = {"アバターの選択", "次", "街", "最初のキャラクター", "セカンドキャラクター", "第三キャラクター", "テキストを入力…", "地図", "出口", "抱歉，我們現在不可用",
        "知らせ", "KOEX（江南）", "Hongdae","閉じる","地域","全体","予期しないバグが発生しました。" ,"移動中です"};

    string[] strCN = {"頭像選擇", "下一個", "街道", "第一個字符", "第二個字符", "第三個字符", "輸入文字...", "地圖", "出口", "Sorry we're not available right now",
        "注意", "KOEX（江南）", "Hongdae","特寫","區域","全部","發生了意外的錯誤。","在移動中" };
}
