using DG.Tweening;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using MyDefines.Enum;

public class PlayerCanvas : MonoBehaviour
{
    public static PlayerCanvas Instance { get; private set; }
    [Header("ItemLog")]
    [SerializeField] private GameObject ItemLog;
    [SerializeField] private Image ItemLogIcon;
    [Header("Chat")]
    [SerializeField] private CanvasGroup ChatBoxCanvasGroup;
    [SerializeField] private Text ChatText;
    [Header("State Box")]
    [SerializeField] private CanvasGroup StateBoxCanvasGroup;
    [SerializeField] private Text StateText;

    private IEnumerator coroChatBoxDirect;
    private IEnumerator coroStateBoxDirect;
    private IEnumerator coroGetItem = null;

    public Text userID;
    public Image gender;

    public void InitSettingsUI(string nick)
    {
        userID.text = nick;
        //if (gender_ == "male")
        //{
        //    gender.color = new Color(0, 0.5f, 1f, 1f);
        //}
        //else
        //{
        //    gender.color = new Color(1f, 0.5f, 1f, 1f);
        //}
    }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
            return;
        }

        //if (GameManager.Instance != null)
        //{
        //    GameManager.Event.AddEvent(Event_Type.UFO, this.UFOCollision);

        //    GameManager.Event.GetItem -= GetItem;
        //    GameManager.Event.GetItem += GetItem;

        //    GameManager.Event.SendChat -= ShowChatBox;
        //    GameManager.Event.SendChat += ShowChatBox;
        //}

       // ChatBoxCanvasGroup.gameObject.SetActive(false);
       // StateBoxCanvasGroup.gameObject.SetActive(false);
      //  ItemLog.SetActive(false);
    }

    //private void OnDestroy()
    //{
    //    if (GameManager.Instance != null)
    //    {
    //        GameManager.Event.RemoveEvent(Event_Type.UFO, this.UFOCollision);

    //        GameManager.Event.GetItem -= GetItem;
    //        GameManager.Event.SendChat -= ShowChatBox;
    //    }
    //}

    public void GetItem(ItemType type, int number)
    {
        if (coroGetItem != null)
            StopCoroutine(coroGetItem);
        coroGetItem = eGetItem(type, number);
        StartCoroutine(coroGetItem);
    }

    private IEnumerator eGetItem(ItemType type, int number)
    {
        ItemLog.GetComponentInChildren<Text>().text = "+" + number.ToString();
        ItemLogIcon.sprite = GameManager.Resource.GetItemSprite(type);
        //ItemLogIcon.SetNativeSize();
        ItemLog.GetComponent<RectTransform>().DOKill();
        ItemLog.GetComponent<RectTransform>().DOAnchorPosY(0f, 1f).From(Vector2.down * 0.25f);
        ItemLog.SetActive(true);

        yield return new WaitForSeconds(1f);
        ItemLog.SetActive(false);

        coroGetItem = null;
    }
    
    private void ShowChatBox(string str)
    {
        ChatText.text = str;

        if (coroChatBoxDirect != null)
            StopCoroutine(coroChatBoxDirect);

        coroChatBoxDirect = ChatboxDirect();
        StartCoroutine(coroChatBoxDirect);
    }

    private IEnumerator ChatboxDirect()
    {
        ChatBoxCanvasGroup.gameObject.SetActive(true);
        ChatBoxCanvasGroup.DOFade(1f, 0.5f).From(0f);

        yield return new WaitForSeconds(3f);

        ChatBoxCanvasGroup.DOFade(0f, 0.5f).From(1f);

        yield return new WaitForSeconds(0.5f);

        ChatBoxCanvasGroup.gameObject.SetActive(false);
    }

    private void UFOCollision()
    {
        if (coroStateBoxDirect != null)
            StopCoroutine(coroStateBoxDirect);
        coroStateBoxDirect = this.eStateBoxDirect("빔에 맞았다!", new Color(0.17f, 0.22f, 0.78f, 1f));
        StartCoroutine(coroStateBoxDirect);
    }

    private IEnumerator eStateBoxDirect(string content, Color color)
    {
        StateText.text = content;
        StateText.color = color;

        StateBoxCanvasGroup.gameObject.SetActive(true);
        StateBoxCanvasGroup.DOFade(1f, 0.5f).From(0f);

        yield return new WaitForSeconds(2f);

        StateBoxCanvasGroup.DOFade(0f, 0.5f).From(1f);

        yield return new WaitForSeconds(0.5f);

        StateBoxCanvasGroup.gameObject.SetActive(false);
    }
}
