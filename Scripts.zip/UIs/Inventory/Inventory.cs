using UnityEngine;
using UnityEngine.UI;
using MyDefines.Enum;

public class Inventory : MonoBehaviour
{
    [SerializeField] private ItemListPanel listPanel;
    [SerializeField] private Image CurrentItemIcon;
    [SerializeField] private Image SelectArrowImage;
    
    public void SelectItem(ItemType type)
    {
        // �ӽ� �̹����� ���� & �ӽ� ������� ����
        CurrentItemIcon.sprite = GameManager.Resource.GetItemSprite(type);
        CurrentItemIcon.SetNativeSize();

        // �ӽ����� ��ġ�� ȭ��ǥ �̵�
        Vector2 pos = SelectArrowImage.rectTransform.anchoredPosition;
        pos.y = 83.5f - ((int)type * 35f);
        SelectArrowImage.rectTransform.anchoredPosition = pos;
    }

    public void SelectItem(int type)
    {
        this.SelectItem((ItemType)type);
    }

    
}
