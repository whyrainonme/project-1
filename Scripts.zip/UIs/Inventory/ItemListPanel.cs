using UnityEngine;
using UnityEngine.UI;
using MyDefines.Enum;

public class ItemListPanel : MonoBehaviour
{
    [SerializeField] private Text[] ItemTexts;
    [SerializeField] private Text peachText;
    private void OnEnable()
    {
        this.SetItemList();
    }

    private void SetItemList()
    {
        DBManager db = GameManager.DB;
        for (ItemType i = ItemType.Bicycle; i < ItemType.Max; i++)
        {
            if (i == ItemType.Peach)
                peachText.text = "x " + db.GetItemNumber(ItemType.Peach);
            else
                ItemTexts[(int)i].text = db.GetItemString(i) + " x" + db.GetItemNumber(i);
        }

    }
}
