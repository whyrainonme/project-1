using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;

public class PopupPanel : MonoBehaviour
{
    // PopupType�� ������� �����ؼ� �־����
    [SerializeField] private GameObject[] Popups;
    private Dictionary<PopupType, GameObject> dicPopups;

    //private void Awake()
    //{
    //    dicPopups = new Dictionary<PopupType, GameObject>();

    //    for (int i = 0; i < Popups.Length; i++)
    //    {
    //        Popups[i].SetActive(false);

    //        if (i != (int)PopupType.Chat)Popups[i].GetComponent<RectTransform>().anchoredPosition = Vector2.zero;

    //        dicPopups.Add((PopupType)i, Popups[i]);
    //    }

    //    Popups = null;
    //}

    //public GameObject GetPopup(PopupType type)
    //{
    //    if (dicPopups.ContainsKey(type))
    //        return dicPopups[type];
    //    else
    //        return null;
    //}

    //public void PoupSetActive(PopupType type, bool active)
    //{
    //    if (dicPopups.ContainsKey(type))
    //        dicPopups[type].SetActive(active);
    //    else
    //    {
    //        GameManager.Error.ErrorMessage("해당키가 존재하지 않습니다.");
    //    }
    //}
}
