using UnityEngine;
using UnityEngine.UI;
using MyDefines.Enum;
using System.Runtime.InteropServices;
using System.Collections;
using UnityEngine.EventSystems;
using DG.Tweening;
using System;
using Unity.Mathematics;
//using static UnityEditor.PlayerSettings;

public class ButtonPanel : MonoBehaviour
{
    public GameObject joyStickOBJ;
    public SceneLoadManager SceneLoad;
    bool videoActive = false;
    public GameObject videoUi, map;
    GameObject player;
    public GameObject initMenu, noticePOP, selecDesign, close, emojiview;

    private float _currentScale;
    private float _temp;
    private float _scalingRate = 2;
    public float minScale, maxScale;
    MI_Metaverse metaverse;
    public RectTransform mapIMG;
    public Sprite BGon, BGoff;
    public Image BGImage;
    WebSocketConnect webSocketConnect;
    public Transform mapTr;
    public Button defaultbtn;
    public GameObject sitPosOBJ;
    public GameObject charSetOBJ;
    public GameObject notice;
    private void Awake()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        player = GameObject.Find("Player").gameObject;
        if (!webSocketConnect.checkInit)
        {
            metaverse = new MI_Metaverse();
            metaverse.MetaverseEnter("GANGNAM-COEX");
            webSocketConnect.checkInit = true;
        }
        else
        {
            if (webSocketConnect.rcevMapInfo == null)
            {
                webSocketConnect.sendMessage(3);
            }

        }
        StartCoroutine(CheckNotice());
    }
    void DestroyNotice(GameObject noti)
    {
        Destroy(noti);
        webSocketConnect.noticeData.cmd = null;
        StartCoroutine(CheckNotice());
    }
    IEnumerator CheckNotice()
    {
//        Debug.Log("CheckNotice");
        if (webSocketConnect.noticeData.cmd == "notice")
        {
            GameObject notiOBJ = Instantiate(notice, this.transform);
            Text text = notiOBJ.transform.Find("Text").GetComponent<Text>();
            if (webSocketConnect.noticeData.target_id == null)
            {
                text.text = "<color=" + webSocketConnect.noticeData.text_color + ">" + webSocketConnect.noticeData.text + "</color>";
                text.text = text.text.Replace("\\n", "\n");
            }
            else
            {
                for (int i = 0; i < webSocketConnect.noticeData.target_id.Length; i++)
                {
                    if (webSocketConnect.noticeData.target_id[i] == webSocketConnect.responeseLogin.id)
                    {
                        text.text = "<color=" + webSocketConnect.noticeData.text_color + ">" + webSocketConnect.noticeData.text + "</color>";
                        text.text = text.text.Replace("\\n", "\n");
                    }
                }
            }
            if (webSocketConnect.noticeData.duration > 0)
            {
                yield return new WaitForSeconds(webSocketConnect.noticeData.duration);
                Destroy(notiOBJ);
                webSocketConnect.noticeData.cmd = null;
                StartCoroutine(CheckNotice());
            }
            else
            {
                notiOBJ.transform.Find("exit").gameObject.SetActive(true);
                notiOBJ.transform.Find("exit").GetComponent<Button>().onClick.AddListener(delegate { DestroyNotice(notiOBJ); });
            }
        }
        else
        {
            yield return new WaitForSeconds(0.5f);
            StartCoroutine(CheckNotice());
        }
    }
    private void OnEnable()
    {
        defaultbtn.Select();
    }
    private void Start()
    {
        
        _currentScale = mapIMG.transform.localScale.x;
    }
    public void EmojiviewActive()
    {
        if (emojiview.activeSelf)
        {
            emojiview.SetActive(false);
        }
        else
        {
            emojiview.SetActive(true);
        }
    }
    bool isEmoji = false;
    public void EmoticonActive(int num)
    {
        StartCoroutine(ActionEmote(num));
    }
    IEnumerator ActionEmote(int num)
    {
        if (!isEmoji)
        {
            isEmoji = true;
            webSocketConnect.SendActionMessage("emoji", num.ToString(), player.transform.position);
            CharactorSettings db = GameObject.Find("CharactorDB").GetComponent<CharactorSettings>();
            GameObject emote = Instantiate(db.emoticons[num], GameObject.Find("Player").transform.Find("PlayerCanvas"));
            emote.GetComponent<RectTransform>().sizeDelta = new Vector2(0.6f, 0.6f);
            emote.GetComponent<RectTransform>().DOAnchorPosY(0.8f, 1f).From(new Vector2(0.7f, 0.9f) * 0.2f);
            yield return new WaitForSeconds(2f);
            isEmoji = false;
            Destroy(emote);
        }
    }
    private void Update()
    {
        bool selectedChar = GetComponent<SelectCharactor>().selectedChar;
        //if(Application.platform == RuntimePlatform.Android)
        {
            //if (Input.GetKey(KeyCode.Escape))
            //{
            //    if (map.activeSelf && SelectedMap)
            //    {
            //        map.SetActive(false);
            //    }
            //    if (charSetOBJ.activeSelf && selectedChar)
            //    {
            //        charSetOBJ.SetActive(false);
            //    }
            //}
        }
    }
    public void ADbutton()
    {
        metaverse.SendCmd("adv");
    }
   
    //상호작용버튼
    public void ClickButton1()
    {
        switch (PlayerMove.Instance.state)
        {
           
            case Player_CollisionState.SangsangMadang:
                SceneLoad.SceneLoad(Scene_Type.SangsangMadang, "");
                //StartCoroutine(LoadScene("SangsangMadang"));
                break;
            case Player_CollisionState.Game1:
                SceneLoad.SceneLoad(Scene_Type.WolrdMap, "");
                //StartCoroutine(LoadScene("Game1"));
                break;
            case Player_CollisionState.Present:
                GameManager.Event.GetPreset();
                break;
            case Player_CollisionState.Koex:
                SceneLoad.SceneLoad(Scene_Type.HongDea, "");
                break;
            case Player_CollisionState.HongDea:
                SceneLoad.SceneLoad(Scene_Type.WolrdMap, "");
                break;
            case Player_CollisionState.WD_Stage:
                SceneLoad.SceneLoad(Scene_Type.WD_stage, "");
                break;
            case Player_CollisionState.WD_fan:
                SceneLoad.SceneLoad(Scene_Type.WD_fan, "");
                break;
            case Player_CollisionState.party:
                SceneLoad.SceneLoad(Scene_Type.party, "");
                break;
            case Player_CollisionState.WD_fanRoom:
                SceneLoad.SceneLoad(Scene_Type.WD_fanRoom, "");
                break;
            case Player_CollisionState.wildwild:
                SceneLoad.SceneLoad(Scene_Type.WolrdMap, "");
                break;
            case Player_CollisionState.SBS:
                metaverse.SendSBSstart("1");
                break;
            case Player_CollisionState.default1:
                SceneLoad.SceneLoad(Scene_Type.default1, "");
                break;
            case Player_CollisionState.default2:
                SceneLoad.SceneLoad(Scene_Type.default2, "");
                break;
            case Player_CollisionState.st_HZoddmonster:
                GameObject.Find("st_HZoddmonster").GetComponent<Animator>().SetBool("dance", true);
                break;
            case Player_CollisionState.DrinkLine:
                SceneLoad.SceneLoad(Scene_Type.DrinkLine, "");
                break;
            case Player_CollisionState.KL:
                SceneLoad.SceneLoad(Scene_Type.KL, "");
                break;
            case Player_CollisionState.NEMO:
                SceneLoad.SceneLoad(Scene_Type.NEMO, "");
                break;
            case Player_CollisionState.ODC:
                SceneLoad.SceneLoad(Scene_Type.ODC, "");
                break;
            case Player_CollisionState.Misun:
                SceneLoad.SceneLoad(Scene_Type.Misun, "");
                break;
            case Player_CollisionState.ZAri:
                SceneLoad.SceneLoad(Scene_Type.ZAri, "");
                break;
            case Player_CollisionState.Sit:
               
                player.GetComponent<PlayerMove>().state = Player_CollisionState.SitUp;
                sitPosOBJ.GetComponent<SitAnim>().PlayerSitAction();
                break;
            case Player_CollisionState.SitUp:
                
                player.GetComponent<PlayerMove>().state = Player_CollisionState.None;
                sitPosOBJ.GetComponent<SitAnim>().PlayerSitUpAction();
                break;
            default:
                Jump();
                break;

        }
        
    }
    public void MyRoom()
    {
        SceneLoad.SceneLoad(Scene_Type.My_Room, "");
    }
 
    public void MicOnOff()
    {
      
        webSocketConnect.micState = !webSocketConnect.micState;
        transform.Find("mic").GetComponent<MicOnOff>().MicState(webSocketConnect.micState);
        metaverse.RTCmic(webSocketConnect.micState);
    }
    public void ClickButton2()
    {
        if (GameManager.Instance.soundData)
        {
            GameManager.Instance.soundData = false;
            GameObject.Find("SoundMGR").GetComponent<SoundManager>().SoundStop();
            BGImage.sprite = BGoff;
        }
        else
        {
            GameManager.Instance.soundData = true;
            GameObject.Find("SoundMGR").GetComponent<SoundManager>().SoundNonStop();
            BGImage.sprite = BGon;
        }
    }
    public void ClickButton3()
    {
        //if (!player.GetComponent<PlayerMove>().isJumping)
        //{
        //    //유저들한테 jump신호 전달 
        //    player.GetComponent<PlayerMove>().Jump();
        //}
        //anim.SetTrigger("jump");
        //if (videoActive) {
        //    //Debug.Log("Stop Video");
        //    videoUi.GetComponent<VideoHandler>().StopVideo();
        //    videoUi.SetActive(false);
        //} else {
        //   // Debug.Log("Play Video");
        //    videoUi.GetComponent<VideoHandler>().PlayVideo();
        //    videoUi.SetActive(true);
        //}
        //videoActive = (videoActive) ? false : true;
    }
    public void SendMenuStr(string str)
    {
        metaverse.SendAndroidMenu(str);
    }
    public void ClickButton4()
    {
        
        if (map.activeSelf)
        {
            map.SetActive(false);
            if (!isloading)
            {
                metaverse.SendIconEnable("true");
            }
          
        }
        else
        {
            if (SelectedMap) { close.SetActive(true); }
            map.SetActive(true);
            if (!isloading)
            {
                metaverse.SendIconEnable("false");
            }
        }
    }

    bool SelectedMap = false;
    public bool isloading = false;
    public void SelectMapPos()
    {
        GameObject pos = mapTr.transform.Find(EventSystem.current.currentSelectedGameObject.name).gameObject;
        SelectedMap = true;
        
        Camera.main.orthographicSize = 7f;
        Camera.main.gameObject.transform.parent = GameObject.Find("Player").gameObject.transform;
        Camera.main.gameObject.transform.localPosition = new Vector3(0, 0, -20f);


        if (UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex != 0)
        {
            SceneLoad.SceneLoad(Scene_Type.WolrdMap, "miniMap", pos.transform.position);
        }
        else
        {
            GoSelectPosition(pos.transform.position);
        }
        MapUnActive();


    }
    void GoSelectPosition(Vector3 pos)
    {
        player.transform.position = pos;
        if (SelectedMap)
        {
            WebSocketConnect webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
            if (webSocketConnect.socketState)
            {
                webSocketConnect.sendMessage(1);

            }
        }
    }
    void MapUnActive()
    {
        map.SetActive(false);
        if (!isloading)
        {
            metaverse.SendIconEnable("true");
        }
    }

    public void SelectKoex()
    {
        selecDesign.SetActive(true);
        initMenu.SetActive(false);
        map.SetActive(true);
    }
    public void SelectHongDae()
    {
        if (noticePOP.activeSelf)
        {
            noticePOP.SetActive(false);
        }
        else
        {
            noticePOP.SetActive(true);
        }
    }
    public void Jump()
    {

        player.GetComponent<PlayerMove>().Jump();
    }
}
