using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Security.Policy;

public class MainUI : MonoBehaviour
{
    public ProfileData profile;
    public WebSocketConnect webSocketConnect;
    public Image picture;
    public string pictureURL;
    public Text nick, introduce;
    public GameObject notiOBJ;

    public Image bicPicture;

    public void SelectPicture()
    {
        picture.SetNativeSize();
    }
    public void NotiMessage()
    {
        notiOBJ.SetActive(true);
        Invoke("ExitNoti", 2f);
    }
    void ExitNoti()
    {
        notiOBJ.SetActive(false);
    }
    private void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        StartCoroutine(LoadIMG());
    }
   
    IEnumerator PictureLoad()
    {
        string value = webSocketConnect.responeseLogin.access_token;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/user/info?id=" + webSocketConnect.responeseLogin.id;
        }
        else
        {
            url = "https://api.lilpop.kr/v1/user/info?id=" + webSocketConnect.responeseLogin.id;
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.1f);
            StartCoroutine(PictureLoad());
        }
        else
        {
            profile = JsonConvert.DeserializeObject<ProfileData>(www.downloadHandler.text);
            if (profile.picture.Length > 1)
            {
                pictureURL = profile.picture;
            }
            nick.text = profile.nickname;
            introduce.text = profile.introduce;
            StartCoroutine(LoadIMG());
        }
    }
    IEnumerator LoadIMG()
    {
        if (pictureURL.Length > 0)
        {
            UnityWebRequest www = UnityWebRequestTexture.GetTexture(pictureURL);
            yield return www.SendWebRequest();

            Texture2D texture = ((DownloadHandlerTexture)www.downloadHandler).texture;
            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2());
            picture.sprite = sprite;

        }
        else
        {
            StartCoroutine(PictureLoad());
        }
    }
}
[System.Serializable]
public class ProfileData
{
    public int code;
    public string message;
    public string id;
    public string uuid;
    public string nickname;
    public string gender;
    public string picture;
    public string name;
    public string email;
    public string phone;
    public int peach;
    public int gold;
    public string introduce;
    public string type;
    public string company;
    public string device_os;
    public string app_version;
    public string last_login;
}

