using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System.Text;

[RequireComponent(typeof(CanvasGroup))]
public class LoadingCanvas : MonoBehaviour
{
    [SerializeField] private CanvasGroup canvasGroup;
    [SerializeField] private Text TMP;

    private string content = "�̵����Դϴ�";
    private StringBuilder strBuilder;

    private int dotNumber = 0;
    private float strUpdateInterval = 0.5f;
    private float strUpdateTimer = 0f;

    private void Awake()
    {
        strBuilder = new StringBuilder();
        canvasGroup = this.GetComponent<CanvasGroup>();
        canvasGroup.DOFade(1f, 0.5f).From(0f);
    }

    public void Destroy()
    {
        StartCoroutine(eDestroy());
    }

    private System.Collections.IEnumerator eDestroy()
    {
        canvasGroup.DOFade(0f, 0.5f).From(1f);
        yield return new WaitForSeconds(1f);
        Destroy(this.gameObject);
    }

    private void Update()
    {
        if (strUpdateTimer < strUpdateInterval)
            strUpdateTimer += Time.deltaTime;
        else
        {
            //strBuilder.Clear();

            //strBuilder.Append(content);

            //for (int i = 0; i < dotNumber; i++)
           //     strBuilder.Append('.');

            //TMP.text = strBuilder.ToString();

            strUpdateTimer = 0f;
            //dotNumber++;

            //if (dotNumber > 3)
            //    dotNumber = 0;
        }
    }
}
