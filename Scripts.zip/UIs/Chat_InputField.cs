using UnityEngine;
using TMPro;

public class Chat_InputField : MonoBehaviour
{
    private TMP_InputField InputField;

    private void Awake()
    {
        InputField = this.GetComponent<TMP_InputField>();
    }

    public void SendChat()
    {
        if (InputField.text != "")
        {
            GameManager.Event.SendChat(InputField.text);
            InputField.text = "";
        }
    }
}
