using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class ErrorPopup : MonoBehaviour
{
    private Text tmp;
    private RectTransform rectTransform;

    private void Awake()
    {
        rectTransform = this.GetComponent<RectTransform>();
        rectTransform.anchoredPosition = Vector2.down * 50f;

        if (GameManager.Instance != null)
            GameManager.Error.errorPopup = this;

        rectTransform.DOKill();
        this.gameObject.SetActive(false);
    }

    private void OnEnable()
    {
        rectTransform.DOKill();
        rectTransform.DOScale(1f, 0.5f).SetEase(Ease.OutBounce).From(0.3f);
    }

    public void Pop(string message)
    {
        tmp.text = message;
        this.gameObject.SetActive(true);
    }
}
