using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class AvataSelect : MonoBehaviour
{
    public ShopItems ShopItems;
    WebSocketConnect webSocketConnect;
    public Image prevIMG;
    public Button btn;
    public Text nameText, chName; //id
    public string charactorID;
    bool purchase;
    CharactorSettings charactorSettings;
    SelectCharactor selectCharactor;
    int selectedIndex;
    public Text price;
    public Image priceImg;
    public Sprite gold, peach;
    private void Start()
    {
        charactorID = ShopItems.name;
        prevIMG = GameObject.Find("PrevIMG").GetComponent<Image>();
        nameText = GameObject.Find("name").GetComponent<Text>();
        btn = GameObject.Find("ApplyCharactor").GetComponent<Button>();
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        charactorSettings = GameObject.Find("CharactorDB").GetComponent<CharactorSettings>();
        selectCharactor = GameObject.Find("ButtonPanel").GetComponent<SelectCharactor>();
        chName = GameObject.Find("CHname").GetComponent<Text>(); 
        LoadIMG();
        
    }
    public void SelectedAvata()
    {
        //StartCoroutine(ItemLoad());
        prevIMG.sprite = transform.Find("Image").GetComponent<Image>().sprite;
        selectCharactor.rotateState = 0;
        prevIMG.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        //var prevChild = GameObject.Find("PrevIMG").transform.GetComponentsInChildren<GameObject>();
        //if (prevChild.Length > 0)
        //for(int i = 0; i < prevChild.Length; i++)
        //{
        //    prevChild[i].SetActive(false);
        //}
        chName.text = ShopItems.name;
        nameText.text = ShopItems.name;
        selectCharactor.index = selectedIndex;
        selectCharactor.isSpecial = true;
    }
   
    void LoadIMG()
    {
        //WWW www = new WWW(url);
        //yield return www;
        for(int i = 0; i < charactorSettings.CharactorAnims.Length; i++)
        {
            if (charactorSettings.CharactorAnims[i].charName == ShopItems.code)
            {
                transform.Find("Image").GetComponent<Image>().sprite
                    = charactorSettings.CharactorAnims[i].charactors.walks[0];
                selectedIndex = i;
            }
        }
        transform.Find("name").GetComponent<Text>().text = charactorID;
   
        //price
        //Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0, 0));
    }

     IEnumerator ItemLoad()
    {
       
        string value = webSocketConnect.responeseLogin.access_token;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/shop/item?userid=" + webSocketConnect.responeseLogin.id + "&type=character";
        }
        else
        {
            url = "https://api.lilpop.kr/v1/shop/item?userid=" + webSocketConnect.responeseLogin.id + "&type=character";
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.01f);
            StartCoroutine(ItemLoad());
        }
        else
        {
            var shopData = JsonConvert.DeserializeObject<ShopItemList>(www.downloadHandler.text);
            for(int i = 0; i < shopData.Items.Count; i++)
            {
                if(shopData.Items[i].code == ShopItems.code)
                {
                    if(shopData.Items[i].purchase_time.Length > 1)
                    {
                        btn.GetComponentInChildren<Text>().text = "적용";
                    }
                    else
                    {
                        btn.GetComponentInChildren<Text>().text = "구매";
                    }
                }
                //if (shopData.Items[i].peach > 0)
                //{
                //    priceImg.sprite = peach;
                //    price.text = ShopItems.peach.ToString();
                //}
                //else if (shopData.Items[i].gold > 0)
                //{
                //    priceImg.sprite = gold;
                //    price.text = ShopItems.gold.ToString();
                //}
                //else
                //{
                //    priceImg.sprite = gold;
                //    price.text = "free";
                //}
            }
        }
    }
}

