using System.Collections;
using System.Collections.Generic;
using System.Windows.Forms.DataVisualization.Charting;
using UnityEngine;

public class CharactorSettings : MonoBehaviour
{
    static public CharactorSettings Instance;
    public CharactorItems charactorItems;
    public AnimationInfo[] CharactorAnims;
    public Sprite sprite;
    public GameObject[] emoticons;
    public RuntimeAnimatorController[] animators;
    string path;
    public Sprites[] specialPreview;
    public Sprites[] charactors;
    private void Awake()
    {
        for (int i = 0; i < specialPreview.Length; i++)
        {
            specialPreview[i].charName = specialPreview[i].image.name;
        }
     
    }
    private void Start()
    {
        if (Instance != null)
        {
            Destroy(this.gameObject);

        }
        else
        {
            DontDestroyOnLoad(this.gameObject);
            Instance = this;
        }
        //f = Resources.LoadAll<Sprite>(sprite);
        //for (int i = 0; i < charactorItems.hair.Length; i++)
        //{
        //    for(int j = 0; j < charactorItems.hair[i].color.Length; j++)
        //    {
        //       if( i == 0 || i == 1)
        //        {
        //            charactorItems.hair[i].color[j].anims = Resources.LoadAll<Sprite>("basic/hair/hair_basic" +
        //            (i + 1).ToString() + "/hair_basic" + (i + 1).ToString() + "_" + (i + 1).ToString() + "_" + (j + 1).ToString());

        //        }
        //        else
        //        {
        //            charactorItems.hair[i].color[j].anims = Resources.LoadAll<Sprite>("basic/hair/hair_basic" +
        //            (i + 1).ToString() + "/hair_basic" + (i + 1).ToString() + "_" + (j + 1).ToString());

        //        }

        //    }
        //}
        //for (int i = 0; i < charactorItems.face.Length; i++)
        //{
        //    for (int j = 0; j < charactorItems.face[i].color.Length; j++)
        //    {

        //            charactorItems.face[i].color[j].anims = Resources.LoadAll<Sprite>("basic/face/face"+ (i + 1).ToString());
        //    }
        //}

    }
}
[System.Serializable]
public class AnimationInfo
{
    public string charName;
    public CharactorAnims charactors;
}
[System.Serializable]
public class CharactorAnims
{
    public Sprite[] idles;
    public Sprite[] sits;
    public Sprite[] walks;
    public Sprite[] talks;
    public Sprite[] jumps;
}

[System.Serializable]
public class Sprites
{
    public string charName;
    public Sprite image;
    public Sprite charactor;
}

[System.Serializable]
public class CharactorItems
{
    public List<CharatorItemInfo> hair;
    public List<CharatorItemInfo> face;
    public List<CharatorItemInfo> top;
    public List<CharatorItemInfo> bottom;
    public List<CharatorItemInfo> shoes;
    public List<CharatorItemInfo> hat;
    public List<CharatorItemInfo> faceItem;
    public List<CharatorItemInfo> acc;
    public List<CharatorItemInfo> color;
}
[System.Serializable]
public class CharatorItemInfo
{
   public ItemsColors[] sprices;
   
}
[System.Serializable]
public class ItemsColors
{
    public List<ItemsName> color;
}
[System.Serializable]
public class ItemsName
{
    public List<Sprite> anims;
}