namespace MyDefines
{
    namespace Enum
    {
        // Event
        public enum Event_Type {Streaming_Complete = 0, SendChat, Button1_Click, Button3_Click, GetItem, UFO,  Max }
        // Scene
        public enum Scene_Type { WolrdMap, SangsangMadang, WD_stage, WD_fan,HongDea, default1, default2,party,WD_fanRoom, My_Room,DrinkLine, KL, NEMO, ODC, Misun,ZAri, Max }
        // UI
        public enum PopupType { Chat = 0, Artist_Cam, Streaming,Inventory, Max}

        // Resource - Sprite
        public enum SpriteResourceType 
        { 
            Item_Peach = 0, Item_ConcertTicket, Item_SaleTicket, XRated_Potion, Bicycle,
            Max
        }

        // Inventroy
        public enum ItemType { Bicycle, Concert_Ticket, XRated_Potion, Peach,  Max}
        
        public enum Player_CollisionState { None = 0, SangsangMadang, Cam, Web, Game1, Streaming,
            Present, UFO, SubwayZone, Koex, WD_Stage, WD_fan, Radio,wildwild, ArtistConnect,HongDea,
            Diary, default1, default2,party,adfont, WD_fanRoom,
            WDHJ,WDHS,WDJW,WDSH,WDCI,WDCK,WDCollin,WDDH,WDJH,WDKY, st_HZoddmonster, SBS, DrinkLine, KL, NEMO, ODC, Misun, ZAri, Sit,SitUp,
            Max }
        public enum Player_Dir { BL = 0, FL, BR, FR}
    }
}