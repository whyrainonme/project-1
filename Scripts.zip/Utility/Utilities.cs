namespace My_Utility
{
    public static class StringUtility
    {
        // ä�� �ؽ�Ʈ ������ ���� �Լ�
        public static string SetChatText(string nickName, string content)
        {
            // ����-1
            //return '[' + nickName + "] : " + content;

            // ����-2
            //return '[' + nickName + "] " + content;

            // ����-3
            return nickName + " : " + content;
        }
    }


    public static class Utility
    { 
        public static T GetResourceFromResource<T>(string Fullpath) where T: UnityEngine.Object
        {
            return UnityEngine.Resources.Load<T>(Fullpath);
        }

    
    }

}
