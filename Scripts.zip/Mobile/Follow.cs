using System.Collections;
using System.Collections.Generic;
using Mono.Cecil.Cil;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class Follow : MonoBehaviour
{
    public List<FollowList> followers,follows;
    public WebSocketConnect webSocketConnect;
    public GameObject followerOBJ;
    public int followCnt, followerCnt, blockCnt;
    public Text followCntTxt, followerCntTxt;
    public Transform content;

    public Text F_UI_followCntTxt, F_UI_follwerCntTxt;

    void OnEnable()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        StartCoroutine(FollowLoad("follower"));
        StartCoroutine(FollowLoad("follow"));
    }
    public void FollowerActive()
    {
        F_UI_follwerCntTxt.text = "<color=#FFFC00>팔로워</color>\n" + followerCnt;
        F_UI_followCntTxt.text = "팔로우\n" + followCnt;
        for (int i = 0; i<content.childCount; i++)
        {
            Destroy(content.GetChild(i).gameObject);
        }
        for (int i = 0; i < followers.Count; i++)
        {
            var foll = Instantiate(followerOBJ, content);
            foll.transform.Find("nick").GetComponent<Text>().text = followers[i].nickname;
            //stateMSG

            if (followers[i].picture != null)
            {
                StartCoroutine
                (LoadIMG(foll.transform.Find("Picture").transform.Find("Image").GetComponent<Image>(),
                followers[i].picture));
                StartCoroutine
                   (LoadStateMSG(foll.transform.Find("state").GetComponent<Text>(),
                  followers[i].id));
            }
        }
    }
    public void FollowActive()
    {
        F_UI_follwerCntTxt.text = "팔로워\n" + followerCnt;
        F_UI_followCntTxt.text = "<color=#FFFC00>팔로우</color>\n" + followCnt;
        for (int i = 0; i < content.childCount; i++)
        {
            Destroy(content.GetChild(i).gameObject);
        }
        for (int i=0; i< follows.Count; i++)
        {
            var foll = Instantiate(followerOBJ, content);
            foll.transform.Find("nick").GetComponent<Text>().text = follows[i].nickname;
            //stateMSG

            if (follows[i].picture != null)
            {
                StartCoroutine
                (LoadIMG(foll.transform.Find("Picture").transform.Find("Image").GetComponent<Image>(),
                follows[i].picture));
                StartCoroutine
                    (LoadStateMSG(foll.transform.Find("state").GetComponent<Text>(),
                   follows[i].id));
            }
        }
    }
    IEnumerator LoadStateMSG(Text t,string id)
    {
        string value = webSocketConnect.responeseLogin.access_token;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/user/info?id=" + id;
        }
        else
        {
            url = "https://lilpop.kr/api/v2/user/info?id=" + id;
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.1f);
            Debug.Log(www.error);
            StartCoroutine(LoadStateMSG(t, id));
        }
        else
        {
            var userSerchResult = JsonConvert.DeserializeObject<UserSerchResult>(www.downloadHandler.text);
            if (userSerchResult.introduce != null)
            {
                t.text = userSerchResult.introduce;
            }
        }
    }
    IEnumerator LoadIMG(Image image, string url)
    {
        UnityWebRequest www = UnityWebRequestTexture.GetTexture(url);
        yield return www.SendWebRequest();
        Texture2D texture = ((DownloadHandlerTexture)www.downloadHandler).texture;
        Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2());
        image.sprite = sprite;
    }
    IEnumerator FollowLoad(string type)
    {
        string value = webSocketConnect.responeseLogin.access_token;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/follow/list?id=" + webSocketConnect.responeseLogin.id
                + "&type="+ type;
        }
        else
        {
            url = "https://lilpop.kr/api/v2/follow/list?id=" + webSocketConnect.responeseLogin.id
                + "&type="+ type;
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.1f);
            Debug.Log(www.error + " "+type);
            StartCoroutine(FollowLoad(type));
        }
        else
        {
            var followInfo = JsonConvert.DeserializeObject<FollowInfo>(www.downloadHandler.text);
            if (followInfo.list != null)
            {
                switch (type)
                {
                    case "follow":
                        follows = followInfo.list;
                        followCnt = followInfo.list.Count;
                        F_UI_followCntTxt.text = "팔로우\n" + followCnt;
                        followCntTxt.text = "팔로우\n" + followCnt;
                        break;
                    case "follower":
                        followers = followInfo.list;
                        followerCnt = followInfo.list.Count;
                        F_UI_follwerCntTxt.text = "팔로워\n" + followerCnt;
                        followerCntTxt.text = "팔로워\n" + followerCnt;
                        break;
                    case "block":
                        blockCnt = followInfo.list.Count;
                        break;

                }
            }
            else
            {
                switch (type)
                {
                    case "follow":
                        followCntTxt.text = "팔로우\n" + 0;
                        break;
                    case "follower":
                        followerCntTxt.text = "팔로워\n" + 0;
                        break;
                    case "block":
                        blockCnt = followInfo.list.Count;
                        break;

                }
            }
            yield return new WaitForSeconds(0.1f);
          
        }
    }
}

[System.Serializable]
public class FollowList
{
    public string id;
    public string user_type;
    public bool online;
    public string nickname;
    public bool friend;
    public string gender;
    public string picture;
    public bool live_noti;
    public bool chat_noti;
}
[System.Serializable]
public class FollowInfo
{
    public int code;
    public string message;
    public string type;
    public int total_count;
    public int find_count;
    public int last_offset;
    public List<FollowList> list;
}
[System.Serializable]
public class UserSerchResult
{
    public int code;
    public string message;
    public string id;
    public string uuid;
    public string nickname;
    public string gender;
    public string picture;
    public string introduce;
    public bool is_follow;
}