using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using MyDefines.Enum;
using Newtonsoft.Json;
using UnityEngine.UIElements;
//using System.Windows.Forms.DataVisualization.Charting;

public class MobileInterface : MonoBehaviour
{
    static public MobileInterface Instance;
       MI_Metaverse metaverse;
     //MobileInterface instance;
#if UNITY_IOS
    [DllImport ("__Internal")] 
    private static extern void unityToIos(string str);
    public static void UnityToIos(string str) {
        unityToIos(str);
    }
#endif

#if UNITY_ANDROID
    static AndroidJavaObject _activity;

    void Awake()
    {

        if (Instance != null)
        {
            Destroy(this.gameObject);

        }
        else
        {
            DontDestroyOnLoad(this.gameObject);
            Instance = this;
        }
        AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        _activity = jc.GetStatic<AndroidJavaObject>("currentActivity");
        
        //      Debug.Log("MobileInterface Awake!");
    }
#endif

    // Start is called before the first frame update
    void Start()
    {
        metaverse = new MI_Metaverse();
       // metaverse.MetaverseEnter("korea-gangnam-coex");
    }

    //// Update is called once per frame
    //public void SendMapChange(string sceneName)
    //{
    //    metaverse.MetaverseMoveMap(sceneName);
    //}

    public static void UnityToMobile(string json)
    {
        //  Debug.Log("UnityToMobile" + json);
#if UNITY_ANDROID
        if (Application.platform == RuntimePlatform.Android)
        {
            _activity.Call("UnityToAndroid", json);
        }
#elif UNITY_IOS
        if (Application.platform == RuntimePlatform.IPhonePlayer)
        {
            UnityToIos(json);
        }
#endif
    }
    public WebSocketConnect webSocketConnect;
    public PlayerCanvas playerCanvas;
   // public GameObject mainCanvas;
    public void MobileToUnity(string str)
    {
      //  Debug.Log("MobileToUnity"+str);

        var logindata = JsonConvert.DeserializeObject<ResponeseLogin>(str);
        if (logindata.cmd == "logout")
        {
            webSocketConnect.DisconnectWebsocket();
        }
        if (logindata.cmd == "user_info")
        {
            webSocketConnect.responeseLogin = logindata;
            if (logindata.nickname != null)
            {
                playerCanvas.InitSettingsUI(logindata.nickname);
            }
        }
        else if(logindata.cmd == "webrtc")
        {
            var StateWebRTC = JsonConvert.DeserializeObject<StateWebRTC>(str);
            if(StateWebRTC.start_mode == "start" && StateWebRTC.webrtc_type == "video")
            {
                webSocketConnect.DisconnectWebsocket();
            }
            else if (StateWebRTC.start_mode == "end" && StateWebRTC.webrtc_type == "video")
            {
              StartCoroutine(webSocketConnect.RequestToken());
            }
        }
        else if (logindata.cmd == "myroom")
        {
            if (str.Contains("enter"))
            {
                //GameManager.Scene.SceneLoad(Scene_Type.My_Room, "");
                GameManager.Instance.lastPOS = GameObject.Find("Player").transform.position;
            }
            else
            {
               // GameManager.Scene.SceneLoad(Scene_Type.WolrdMap, "");
                GameManager.Instance.lastPOS = Vector2.zero;
            }
        }
        else if (logindata.cmd == "settings")
        {
            if (str.Contains("language"))
            {
                var Language = JsonConvert.DeserializeObject<EditLanguage>(str);
                webSocketConnect.language = Language.language;
            }
            if (str.Contains("nickname"))
            {
                var Nickname = JsonConvert.DeserializeObject<EditNickname>(str);
                webSocketConnect.responeseLogin.nickname = Nickname.nickname;
                playerCanvas.InitSettingsUI(Nickname.nickname);
            }
            if (str.Contains("effect"))
            {
                var effect = JsonConvert.DeserializeObject<EffectSound>(str);
                if (effect.effect == "true")
                {
                    webSocketConnect.effectSound = true;
                }
                else if (effect.effect == "false")
                {
                    webSocketConnect.effectSound = false;
                }
            }
        }
        else if(logindata.cmd == "voice_detect")
        {
            var voice_detect = JsonConvert.DeserializeObject<Voice_Detect>(str);
            if(voice_detect.user == webSocketConnect.responeseLogin.id)
            {
                GameObject player = GameObject.Find("Player");
                Vector3 pos = player.transform.position;
                if (voice_detect.voice == "start")
                {
                    GameObject.Find("Player").GetComponent<PlayerEnterArea>().voiceEffect.SetActive(true);
                    GameObject.Find("Player").GetComponent<PlayerMove>().isTalk = (true);
                    webSocketConnect.SendActionMessage("voice", "start", pos);
                }
                else
                {
                    GameObject.Find("Player").GetComponent<PlayerEnterArea>().voiceEffect.SetActive(false);
                    GameObject.Find("Player").GetComponent<PlayerMove>().isTalk = (false);
                    webSocketConnect.SendActionMessage("voice", "end", pos);
                }
            }
            else
            {
                //var users = GameObject.FindGameObjectsWithTag("users");
                //foreach (var userlist in users)
                //{
                //    if(voice_detect.user == userlist.GetComponent<UsersMove>().userID.text)
                //    {
                //        if (voice_detect.voice == "start")
                //        {
                //            userlist.GetComponent<UsersMove>().voiceEffect.SetActive(true);
                //        }
                //        else
                //        {
                //            userlist.GetComponent<UsersMove>().voiceEffect.SetActive(false);
                //        }
                //    }
                //}
            }
        }
    }

    public void AndroidToUnity(string str)
    {
        //Debug.Log("Mobile To Unity");
        MobileToUnity(str);
    }

    public void IosToUnity(string str)
    {
        MobileToUnity(str);
    }
}
