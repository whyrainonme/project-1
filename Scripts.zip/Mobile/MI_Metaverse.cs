using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class EditNickname
{
    public string cmd;
    public string nickname;
}
[System.Serializable]
public class AndroidMenu
{
    public string cmd;
    public string menu;
}
[System.Serializable]
public class EffectSound
{
    public string cmd;
    public string effect;
}
[System.Serializable]
public class OnlyCMD
{
    public string cmd;
}
[System.Serializable]
public class EditLanguage
{
    public string cmd;
    public string language;
}
[System.Serializable]
public class Voice_Detect
{
    public string cmd;
    public string user;
    public string voice;
}
[System.Serializable]
public class StringSend
{
    public string cmd;
}
[System.Serializable]
public class EnterWebRTC
{
    public string cmd;
    public string type;
    public string map;
    public string area;
    public bool muted;
    public LoadWebRTC loadWebRTC;
}
[System.Serializable]
public class LoadWebRTC
{
    public int code;
    public string message;
    public string room_id;
    public string room_type;
    public string room_name;
    public string owner_id;
    public string ws_address;
    public string turn_address;
    public int max_user;
    public int curr_user;
}
[System.Serializable]
public class ExitWebRTC
{
    public string cmd;
    public string type;
    public string map;
    public string area;
}
[System.Serializable]
public class RTCMuted
{
    public string cmd;
    public string type;
    public bool muted;
}
[System.Serializable]
public class StateWebRTC
{
    public string cmd;
    public string webrtc_type;
    public string start_mode;
    }
[System.Serializable]
public class Metaverse {
    public string cmd;
    public string map;
}
[System.Serializable]
public class IconEnable
{
    public string cmd;
    public string enable;
}
[System.Serializable]
public class UserInfo
{
    public string cmd;
    public string user_id;
}
[System.Serializable]
public class ArtistInfo
{
    public string cmd;
    public string artist_id;
}
[System.Serializable]
public class SBSsend
{
    public string cmd;
    public string value;
}
[System.Serializable]
public class MediaData
{
    public string cmd;
    public string type;
    public string url;
}
public class MI_Metaverse : MonoBehaviour
{
    MI_Metaverse Instance;
    void Awake()
    {

        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
            return;
        }

    }
    public void SendCmd(string cmd)
    {
        OnlyCMD data = new OnlyCMD();
        data.cmd = cmd;
        string json = JsonUtility.ToJson(data);
        MobileInterface.UnityToMobile(json);
    }
    public void SendMediaData(string type, string url)
    {
        MediaData media = new MediaData();
        media.cmd = "settings";
        media.type = type;
        media.url = url;
        string json = JsonUtility.ToJson(media);
        MobileInterface.UnityToMobile(json);
    }
    public void SendMetaverse(string type, string area)
    {
        Metaverse meta = new Metaverse();
        meta.cmd = type;
        meta.map = area;
        string json = JsonUtility.ToJson(meta);
        MobileInterface.UnityToMobile(json);
    }
    public void SendString(string str)
    {
        StringSend strSend = new StringSend();
        strSend.cmd = str;
        string json = JsonUtility.ToJson(strSend);
        MobileInterface.UnityToMobile(json);
    }
    public void SendSBSstart(string value)
    {
        SBSsend sbs = new SBSsend();
        sbs.cmd = "settings";
        sbs.value = value;
        string json = JsonUtility.ToJson(sbs);
        MobileInterface.UnityToMobile(json);
    }
    public void SendIconEnable(string enable)
    {
//        Debug.Log(enable);
        //IconEnable icon = new IconEnable();
        //icon.cmd = "icons";
        //icon.enable = enable;
        //string json = JsonUtility.ToJson(icon);
      //  MobileInterface.UnityToMobile(json);
    }
    public void SendAndroidMenu(string menuStr)
    {
        AndroidMenu menu = new AndroidMenu();
        menu.cmd = "menu";
        menu.menu = menuStr;
        string json = JsonUtility.ToJson(menu);
        MobileInterface.UnityToMobile(json);
    }
    public void SendUserInfo(string thisID)
    {
        UserInfo user = new UserInfo();
        user.cmd = "user_touch";
        user.user_id = thisID;
        string json = JsonUtility.ToJson(user);
        MobileInterface.UnityToMobile(json);
    }
    public void SendArtistInfo(string thisID)
    {
        ArtistInfo artist = new ArtistInfo();
        artist.cmd = "artist_touch";
        artist.artist_id = thisID;
        string json = JsonUtility.ToJson(artist);
        MobileInterface.UnityToMobile(json);
    }

    public void EnterRTC(string map, string area, bool muted)
    {
        EnterWebRTC enterWeb = new EnterWebRTC();
        enterWeb.cmd = "webrtc";
        enterWeb.type = "enter";
        enterWeb.map = map;
        enterWeb.area = area;
        enterWeb.muted = muted;
        enterWeb.loadWebRTC = GameObject.Find("Player").GetComponent<PlayerEnterArea>().loadWebRTC;
        string json = JsonUtility.ToJson(enterWeb);
        MobileInterface.UnityToMobile(json);
    }
    public void ExitRTC(string map, string area)
    {
        ExitWebRTC exitWeb = new ExitWebRTC();
        exitWeb.cmd = "webrtc";
        exitWeb.type = "exit";
        exitWeb.map = map;
        exitWeb.area = area;

        string json = JsonUtility.ToJson(exitWeb);
        MobileInterface.UnityToMobile(json);
    }
    public void RTCmic(bool muted)
    {
        RTCMuted mic = new RTCMuted();
        mic.cmd = "mic_click"; //webrtc
        mic.type = "enter";
        mic.muted = muted;
        string json = JsonUtility.ToJson(mic);
        MobileInterface.UnityToMobile(json);
    }
    public void MetaverseEnter(string area) {
        SendMetaverse("init", area);
    }
    public void MetaverseMoveMap(string area)
    {
        SendMetaverse("map", area);
    }
    public void MetaverseExit(string area) {
        SendMetaverse("exit", area);
    }

    public void MetaverseMove(string area) {
        SendMetaverse("move", area);
    }

    public string ObjectToJson(object obj) {
        return JsonUtility.ToJson(obj, true);
    }

    T JsonToObject<T>(string JsonData) where T : class {
        return JsonUtility.FromJson<T>(JsonData);
    }

}
