using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;

public class PlayerCollision : MonoBehaviour {

    Color alphaColor = new Vector4(1, 1, 1, 0.5f);
    Color OriginalColor = new Vector4(1, 1, 1, 1);
    Tilemap tile;
    SpriteRenderer sprite;
    public Sprite[] sprites;
    public bool tilemap;
    private void Awake()
    {
        if (sprites.Length > 0)
        {
            StartCoroutine(AnimationSprites());
        }
        if (!tilemap)
        {
            sprite = GetComponent<SpriteRenderer>();
        }
        else
        {
            tile = GetComponent<Tilemap>();
        }
       
    }
   
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player" && collision.gameObject.GetComponent<PlayerMove>().state != MyDefines.Enum.Player_CollisionState.Sit)
        {
            //Debug.Log(transform.localPosition.y + " vs " + collision.transform.parent.localPosition.y);
            if (transform.position.y <= collision.transform.localPosition.y)
            {
                if (!tilemap)
                {
                    sprite.color = alphaColor;
                }
                else
                {
                    tile.color = alphaColor;
                }
            }
        }
       
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "users")
        {
            if ((transform.position.y <= collision.transform.localPosition.y) && !collision.GetComponent<UsersMove>().sitState)
            {
                collision.GetComponent<SpriteRenderer>().sortingOrder = 12;
            }
            else
            {
                collision.GetComponent<SpriteRenderer>().sortingOrder = 14;
            }
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            if (!tilemap)
            {
                sprite.color = OriginalColor;
            }
            else
            {
                tile.color = OriginalColor;
            }
        }
        if (collision.tag == "users")
        {
            collision.GetComponent<SpriteRenderer>().sortingOrder = 14;
        }
    }
    IEnumerator AnimationSprites()
    {
        yield return new WaitForSeconds(0.2f);
        this.GetComponent<SpriteRenderer>().sprite = sprites[0];
        yield return new WaitForSeconds(0.2f);
        this.GetComponent<SpriteRenderer>().sprite = sprites[1];
        StartCoroutine(AnimationSprites());
    }
}
