using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class UFO : MonoBehaviour
{
    private SpriteRenderer beamRenderer;
    private Animator animator;
    private Transform PlayerDestinationTransform;
    private ParticleSystem particle;

    [SerializeField] private Vector3[] StartsPositions;
    [SerializeField] private Vector3[] DestPositions;
    [SerializeField] private int PositionIndex = 0;

    private float MoveSpeed = 3f;
    private float LerpTimer = 0f;
    private float MaxTime;

    private bool IsCollided = false;
    private bool IsAbleToMove = true;

    private void Awake()
    {
        animator = this.GetComponent<Animator>();
        beamRenderer = this.transform.Find("Beam").GetComponent<SpriteRenderer>();
        particle = this.GetComponentInChildren<ParticleSystem>();
        PlayerDestinationTransform = this.transform.Find("Player_Transform");


        particle.gameObject.SetActive(false);
        beamRenderer.enabled = false;
        MaxTime = (DestPositions[0] - StartsPositions[0]).magnitude / MoveSpeed;
    }

    private void Update()
    {
        if (IsAbleToMove == false) return;

        if (LerpTimer < MaxTime)
        {
            LerpTimer += Time.deltaTime;
            this.transform.position = Vector3.Lerp(StartsPositions[PositionIndex], DestPositions[PositionIndex], LerpTimer / MaxTime);
        }
        else
        {
            LerpTimer = 0f;
            PositionIndex++;
            IsCollided = false;
            if (PositionIndex >= StartsPositions.Length)
                PositionIndex = 0;
        }
    }

    private IEnumerator eBeamAnimation()
    {

        IsAbleToMove = false;
        beamRenderer.enabled = true;
        animator.Play("UFO_Beam", 0, 0f);

        yield return new WaitForSeconds(1f);
        particle.gameObject.SetActive(true);
        particle.Play();
        animator.Play("UFO_BeamOff", 0, 0f);

        yield return new WaitForSeconds(1f);

        beamRenderer.enabled = false;
        PlayerMove.Instance.state = MyDefines.Enum.Player_CollisionState.None;
        GameManager.Event.GetItem(MyDefines.Enum.ItemType.Concert_Ticket, 1);
        IsAbleToMove = true;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (IsCollided == false && collision.transform.name == "Player")
        {
            //StartCoroutine(eBeamAnimation());
            //GameManager.Event.EventInvoke(MyDefines.Enum.Event_Type.UFO);
            PlayerMove.Instance.state = MyDefines.Enum.Player_CollisionState.UFO;
          //  PlayerMove.Instance.MoveToPosition(PlayerDestinationTransform.position);
            IsCollided = true;
        }
    }
}
