using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PresentList : MonoBehaviour
{
    public Present CollidedPresent = null;

    private void Awake()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Event.GetPreset -= GetPresent;
            GameManager.Event.GetPreset += GetPresent;
        }
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Event.GetPreset -= GetPresent;
        }
    }

    public void ReleasePresent(Present present)
    {
        if (CollidedPresent.GetInstanceID() == present.GetInstanceID())
            CollidedPresent = null;
    }

    public void GetPresent()
    {
        if (CollidedPresent != null)
        {
            GameManager.Event.GetItem(CollidedPresent.ItemData.type, CollidedPresent.ItemData.number);
            PlayerMove.Instance.state = MyDefines.Enum.Player_CollisionState.None;
            CollidedPresent.Delete();
            CollidedPresent = null;
        }
    }
}
