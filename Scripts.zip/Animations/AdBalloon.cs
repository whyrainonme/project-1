using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AdBalloon : MonoBehaviour
{
   
    private Transform PlayerDestinationTransform;
   
    [SerializeField] private Vector3[] StartsPositions;
    [SerializeField] private Vector3[] DestPositions;
    [SerializeField] private int PositionIndex = 0;

    private float MoveSpeed = 3f;
    private float LerpTimer = 0f;
    private float MaxTime;


    private void Awake()
    {
         PlayerDestinationTransform = this.transform.Find("Player_Transform");
         MaxTime = (DestPositions[0] - StartsPositions[0]).magnitude / MoveSpeed;
    }

    private void Update()
    {
        
        if (LerpTimer < MaxTime)
        {
            LerpTimer += Time.deltaTime;
            this.transform.position = Vector3.Lerp(StartsPositions[PositionIndex], DestPositions[PositionIndex], LerpTimer / MaxTime);
        }
        else
        {
            LerpTimer = 0f;
            PositionIndex++;
            if (PositionIndex >= StartsPositions.Length)
                PositionIndex = 0;
        }
    }

    
 
}
