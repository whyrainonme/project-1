using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WildStage : MonoBehaviour
{
     Animator anim;
    public float lateTime;
    void Start()
    {
        anim = GetComponent<Animator>();
        StartCoroutine(ActorAnim());
    }
    IEnumerator ActorAnim()
    {
        yield return new WaitForSeconds(lateTime);
        anim.SetTrigger("dance");
        StartCoroutine(ActorAnim());
    
    }
}
