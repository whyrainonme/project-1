using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OddHZmonster : MonoBehaviour
{
    public AudioClip[] audioClips;
    AudioSource AudioSource;
    private void Start()
    {
        AudioSource = GetComponent<AudioSource>();
    }
    public void AudioPlay(int num)
    {
        //AudioSource.clip = audioClips[num];
        AudioSource.PlayOneShot(audioClips[num]);
    }
}
