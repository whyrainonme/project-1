using UnityEngine;
using DG.Tweening;
using MyDefines.Enum;

public class Present : MonoBehaviour
{
    [SerializeField] private SpriteRenderer BlinkSpRenderer;
    public (ItemType type, int number) ItemData;
    private bool IsDeleted = false;
    Color color;
    private void Awake()
    {
        // ?????? ?????? ?????? ????
        ItemData.type = (ItemType)Random.Range(0, (int)ItemType.Max);
        ItemData.number = Random.Range(1, 3);
        color = BlinkSpRenderer.color;
    }

    public void Delete()
    {
        IsDeleted = true;
        StartCoroutine(eDelete());
    }

    private System.Collections.IEnumerator eDelete()
    {
        BlinkSpRenderer.DOKill();
        BlinkSpRenderer.enabled = false;
        this.GetComponent<SpriteRenderer>().DOColor(Color.clear, 1f).From(Color.white);
        yield return new WaitForSeconds(1f);

        Destroy(this.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            BlinkSpRenderer.DOColor(new Color(1f, 1f, 1f, 0.5f), 1f).From(new Color(1f, 1f, 1f, 0f)).SetLoops(-1, LoopType.Yoyo);
            PlayerMove.Instance.state = Player_CollisionState.Present;

            this.transform.parent.GetComponent<PresentList>().CollidedPresent = this;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (IsDeleted) return;

        if(collision.CompareTag("Player"))
        {
            BlinkSpRenderer.DOKill();
            BlinkSpRenderer.color = color;
            PlayerMove.Instance.state = Player_CollisionState.None;

            this.transform.parent.GetComponent<PresentList>().ReleasePresent(this);
        }
    }
}
