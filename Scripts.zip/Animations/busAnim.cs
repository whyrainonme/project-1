using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class busAnim : MonoBehaviour
{
    public Transform start, end;
    public float speed, distance;
    NavMeshAgent agent;
    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();

    }
    // Update is called once per frame
    void Update()
    {
        if (Vector2.Distance(transform.localPosition,end.localPosition) < distance)
        {
            this.transform.localPosition = start.localPosition;
        }
        else
        {
            this.transform.localPosition = Vector3.MoveTowards(transform.localPosition, end.localPosition, speed * Time.deltaTime);
        }
    }
}
