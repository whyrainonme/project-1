using System.Collections;
using System.Collections.Generic;
using MyDefines.Enum;
using UnityEngine;
//using static UnityEditorInternal.VersionControl.ListControl;

public class SitAnim : MonoBehaviour
{
    public bool available = true;
    public GameObject target;
    Transform tr;
    public enum rotateDir
    {
        FL, FR, BR, BL
    }
    public rotateDir r;

    private void Start()
    {
        tr = transform.GetComponent<Transform>();
    }
   
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "Player"&& collision.gameObject.GetComponent<PlayerMove>().state == Player_CollisionState.None)
        {
            collision.gameObject.GetComponent<PlayerMove>().state = Player_CollisionState.Sit;
            collision.gameObject.GetComponent<PlayerMove>().sitPos = tr.position;
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
            GameObject.Find("ButtonPanel").GetComponent<ButtonPanel>().sitPosOBJ = this.gameObject;
        }
        else if (collision.tag == "users" && collision.gameObject.GetComponent<UsersMove>().sitState == true)
        {
            available = false;
            collision.gameObject.GetComponent<UsersMove>().sitPosOBJ = this.gameObject;

            //collision.gameObject.GetComponent<UsersMove>().SitDownAnim();
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player" && (collision.gameObject.GetComponent<PlayerMove>().state == Player_CollisionState.Sit || collision.gameObject.GetComponent<PlayerMove>().state == Player_CollisionState.SitUp))
        {
            collision.gameObject.GetComponent<PlayerMove>().state = Player_CollisionState.None;
        }
        else if (collision.tag == "users")
        {
            available = true;
            collision.gameObject.GetComponent<UsersMove>().sitPosOBJ = this.gameObject;
        }
    }
    
    public void PlayerSitAction()
    {
        if (available)
        {
            GameObject.Find("Player").GetComponent<PlayerMove>().SitAnimation(r); // 애니메이션 , 위치 처맆
        }
    }
    public void PlayerSitUpAction()
    {
            GameObject.Find("Player").GetComponent<PlayerMove>().SitUpAnimation(r); // 애니메이션 , 위치 처맆
    }
    public void SitUpAction(Vector3 pos)
    {
        available = true;
        GameObject.Find("Player").GetComponent<Transform>().position = pos;
    }

}
