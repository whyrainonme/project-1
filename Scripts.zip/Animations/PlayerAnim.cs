using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using UnityEngine;
using UnityEngine.UI;

public class PlayerAnim : MonoBehaviour
{
    public string SpriteSheetName;
    private string LoadedSpriteSheetName;
     Dictionary<string, Sprite> spriteSheet;
     SpriteRenderer spriteRenderer;
     Image imageRenderer;
    public bool image;
    public Sprite[] sprites;
    private void Start()
    {
        if (!image)
        {
            this.spriteRenderer = GetComponent<SpriteRenderer>();
        }
        else
        {
            this.imageRenderer = GetComponent<Image>();
        }

        this.LoadSpriteSheet();
    }
    private void LateUpdate()
    {
        if (this.LoadedSpriteSheetName != this.SpriteSheetName)
        {
            this.LoadSpriteSheet();
        }
        if (!image)
        {
            this.spriteRenderer.sprite = this.spriteSheet[this.spriteRenderer.sprite.name];
        }
        else
        {
            this.imageRenderer.sprite = this.spriteSheet[this.imageRenderer.sprite.name];
        }
    }
    private void LoadSpriteSheet()
    {
        //for (int i = 0; i < charactorSettings.f.Length; i++)
        //{
        //    if (this.SpriteSheetName == charactorSettings.f[i].charName)
        //    {
        //        sprites = charactorSettings.f[i].charactor;//Resources.LoadAll<Sprite>(this.SpriteSheetName);
        //    }
        //}
        sprites =  Resources.LoadAll<Sprite>("Char/"+this.SpriteSheetName);
        this.spriteSheet = sprites.ToDictionary(x => x.name, x => x);
        // ("Char/" + this.SpriteSheetName);

        this.LoadedSpriteSheetName = this.SpriteSheetName;
    }

}
