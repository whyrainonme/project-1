using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemInfomation : MonoBehaviour
{
    public ShopItems ShopItems;
    public Image itemIMG;
    public GameObject menu;
    public GameObject item;

    private void Start()
    {
        StartCoroutine(LoadIMG(ShopItems.image));
    }
    IEnumerator LoadIMG(string url)
    {
        WWW www = new WWW(url);
        yield return www;
        itemIMG.sprite = Sprite.Create(www.texture, new Rect(0, 0, www.texture.width, www.texture.height), new Vector2(0, 0));
    }
    public void MenuOpen()
    {
        menu.SetActive(true);
    }
    public void Apply()
    {
        menu.SetActive(false);
        GameObject sprite = Instantiate(item, null);
        sprite.GetComponent<SpriteRenderer>().sprite = itemIMG.sprite;
        sprite.AddComponent<PolygonCollider2D>().isTrigger = true;
    }
    public void AddMyBucket()
    {
        menu.SetActive(false);
    }
}
