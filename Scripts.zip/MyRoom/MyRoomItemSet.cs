using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyRoomItemSet : MonoBehaviour
{
    public GameObject store, mylist, edit, hide;
    public GameObject[] deadzone;
    public bool storeOpen, mylistOpen, editOpen;
    public GameObject removeUI;
    public SpriteRenderer SelectedSprite;
    public Image previewIMG;
    public Camera camera;
    public bool editMode = false;
    Vector3 originTr;
    ItemDir itemDir = ItemDir.FR;
    MI_Metaverse metaverse;
    GameObject mainCanvas;
    GameObject player;
    private void Start()
    {
        metaverse = new MI_Metaverse();
        camera = GameObject.Find("Player").transform.Find("Main Camera").GetComponent<Camera>();
        mainCanvas = GameObject.Find("MainCanvas").gameObject;
        player = GameObject.Find("Player").gameObject;
    }
    public void LayerSet(bool isdown)
    {
        if (!isdown) { SelectedSprite.sortingOrder += 1; }
        else
        {
            if (SelectedSprite.sortingOrder > 0) SelectedSprite.sortingOrder -= 1;
        }
    }
    public void RotateItem()
    {
        switch (itemDir)
        {
            case ItemDir.FR:
                SelectedSprite.flipX = true;
                //SelectedSprite.sprite = SelectedSprite.GetComponent<ItemDrag>().rotationSprites[0];
                itemDir = ItemDir.FL;
                break;
            case ItemDir.FL:
                SelectedSprite.flipX = false;
                //SelectedSprite.sprite = SelectedSprite.GetComponent<ItemDrag>().rotationSprites[1];
                itemDir = ItemDir.BR;
                break;
            case ItemDir.BR:
                SelectedSprite.flipX = true;
                //SelectedSprite.sprite = SelectedSprite.GetComponent<ItemDrag>().rotationSprites[1];
                itemDir = ItemDir.BL;
                break;
            case ItemDir.BL:
                SelectedSprite.flipX = false;
               // SelectedSprite.sprite = SelectedSprite.GetComponent<ItemDrag>().rotationSprites[0];
                itemDir = ItemDir.FR;
                break;
        }

    }
    public void EditModeOn()
    {
        metaverse.SendIconEnable("false");
        originTr = camera.GetComponent<Transform>().position;
        camera.gameObject.transform.parent = null;
        camera.GetComponent<Transform>().localPosition = new Vector3(6.59f,0.75f,-9.02f);
        player.SetActive(false);
        camera.orthographicSize = 5;
        editMode = true;
        mainCanvas.SetActive(false);
        hide.SetActive(true);
        for(int i = 0; i < deadzone.Length; i++)
        {
            deadzone[i].SetActive(false);
        }
    }
    public void EditModeOff()
    {
        //Save State(Server)
        metaverse.SendIconEnable("true");
        camera.orthographicSize = 5;
        editMode = false;
        removeUI.SetActive(false);
        mainCanvas.SetActive(true);
        hide.SetActive(false);
       
        player.SetActive(true);
        camera.gameObject.transform.parent = player.transform;
        camera.GetComponent<Transform>().position = originTr;
        for (int i = 0; i < deadzone.Length; i++)
        {
            deadzone[i].SetActive(true);
        }
    }
    public void EditModeHideMenu()
    {
        camera.GetComponent<Transform>().position = new Vector3(0,0.86f, -9.02f);
        camera.orthographicSize = 5;
        if (store.activeSelf)
        {
            storeOpen = true;
        }
        if (mylist.activeSelf)
        {
            mylistOpen = true;
        }
        if (edit.activeSelf)
        {
            editOpen = true;
        }
    }
    public void LastOpen()
    {
        if (storeOpen)
        {
            store.SetActive(true);
        }
        if (mylistOpen)
        {
            mylist.SetActive(true);
        }
        if (editOpen)
        {
            edit.SetActive(true);
        }
        storeOpen = false;
        mylistOpen = false;
        editOpen = false;
        camera.GetComponent<Transform>().localPosition = new Vector3(6.59f, 0.75f, -9.02f);
    }
    public void RemoveItem()
    {
        Destroy(SelectedSprite.gameObject);
        removeUI.SetActive(false);
    }
}