using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyRoomDataBase : MonoBehaviour
{
    public RoomType[] roomTypes;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
public enum ItemTypes { FLOOR, WALL, FREE }
public enum ItemDir { FR, FL, BR, BL }
[System.Serializable]
public class Items
{
    public string id;
    public ItemTypes ItemType;
    public ItemDir ItemDir;
    public int layer;
    public Vector3 pos;
}
[System.Serializable]
public class ItemInfo
{
    public Items Items;
}
[System.Serializable]
public class RoomType
{
    public string room_type;
    public Sprite sprite;
}