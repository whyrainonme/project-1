using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using UnityEngine;
using UnityEngine.UI;
public class ItemDrag : MonoBehaviour
{
    public Camera cam;
    public bool editmode = false;
    bool portal = false;
    public Sprite[] rotationSprites;
    MyRoomItemSet MyRoomItemSet;
    GameObject removeUI;
    Vector3 originPos;
    public List<Collider2D> collider2Ds;
    bool onWall, onFloor;
    private void OnEnable()
    {
        var dcollider2Ds = GameObject.FindGameObjectsWithTag("WallNFloor");

        for(int i =0; i < dcollider2Ds.Length; i++)
        {
            collider2Ds.Add(dcollider2Ds[i].GetComponent<Collider2D>());
        }
        removeUI = GameObject.Find("Canvas").transform.Find("Remove").gameObject;
        cam = GameObject.Find("Main Camera").GetComponent<Camera>();
        MyRoomItemSet = GameObject.Find("Canvas").GetComponent<MyRoomItemSet>();
        if (this.gameObject.tag == "portal")
        {
            portal = true;
        }
    }
    private void Update()
    {
        editmode = MyRoomItemSet.editMode;
    }
    private void OnMouseDown()
    {
        if (editmode)
        {
            removeUI.SetActive(false);

            MyRoomItemSet.SelectedSprite = this.GetComponent<SpriteRenderer>();
            MyRoomItemSet.previewIMG.sprite = this.GetComponent<SpriteRenderer>().sprite;

            originPos = transform.position;
        }
    }
    void OnMouseDrag()
    {
        if (editmode)
        {
            for (int i = 0; i < collider2Ds.Count; i++)
            {
                collider2Ds[i].enabled = true;
            }
            removeUI.SetActive(false);
                Vector3 mousePosition = new Vector3(Input.mousePosition.x, Input.mousePosition.y, 10);
                Vector3 objPosition = cam.ScreenToWorldPoint(mousePosition);
                transform.position = new Vector3(objPosition.x, objPosition.y, 0);
               
        }
    }
    private void OnMouseUp()
    {
        if (editmode)
        {
            if(!onWall && !onFloor)
            {
                transform.position = originPos;
            }
           
            removeUI.SetActive(true);
            removeUI.transform.position = cam.WorldToScreenPoint(transform.position + new Vector3(0, 0.8f, 0));
            for (int i = 0; i < collider2Ds.Count; i++)
            {
                collider2Ds[i].enabled = false;
            }
        }

    }
    
    private void OnTriggerStay2D(Collider2D collision)
    {
       if(collision.gameObject.name == "wall")
        {
            onWall = true;
        }
       if(collision.gameObject.name == "floor")
        {
            onFloor = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "wall")
        {
            onWall = false;
        }
        if (collision.gameObject.name == "floor")
        {
            onFloor = false;
        }
    }
    
}
