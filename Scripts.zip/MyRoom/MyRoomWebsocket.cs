using System.Collections;
using System.Collections.Generic;
using WebSocketSharp;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Networking;

public class MyRoomWebsocket : MonoBehaviour
{
    WebSocketConnect webSocketConnect;
    public MyRoomRequest myRoomRequest;
    WebSocket m_WebSocket;
    void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
    }

    public IEnumerator GetText()
    {
        string value = webSocketConnect.responeseLogin.access_token;
        string id = webSocketConnect.responeseLogin.id;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/metaverse/server" + "?myroom=" + id;
        }
        else
        {
            url = "https://api.lilpop.kr/v1/metaverse/server" + "?myroom=" + id;
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.01f);
            StartCoroutine(GetText());
        }
        else
        {
            var loadWebRTCData = JsonConvert.DeserializeObject<MyRoomRequest>(www.downloadHandler.text);
            myRoomRequest = loadWebRTCData;
            webSocketConnect.StartWebsocket();
            webSocketConnect.sendMessage(0);
        }
    }


}
[System.Serializable]
public class MyRoomRequest
{
    public int code;
    public string message;
    public string address;
    public int max_user;
    public int curr_user;
}