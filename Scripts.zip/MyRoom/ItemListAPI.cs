using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using static System.Net.WebRequestMethods;

public class ItemListAPI : MonoBehaviour
{
    public ShopItemList shopItemList;
       WebSocketConnect webSocketConnect;
    public GameObject ItemObject;
    public GameObject ItemList;
  
    // Start is called before the first frame update
    void OnEnable()
    {
        
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        StartCoroutine(CheckTokenLoad());
    }

    IEnumerator CheckTokenLoad()
    {
        if (webSocketConnect.responeseLogin.access_token != null && webSocketConnect.responeseLogin.access_token != "")
        {
            StopCoroutine(CheckTokenLoad());
            StartCoroutine(CharItemLoad());
        }
        else
        {
            yield return new WaitForSeconds(1f);
            StartCoroutine(CheckTokenLoad());
        }
    }
    IEnumerator CharItemLoad()
    {
    

        string value = webSocketConnect.responeseLogin.access_token;
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/shop/item?type=character";
        }
        else
        {
            url = "https://api.lilpop.kr/v1/shop/item?type=character";
        }
        UnityWebRequest www = UnityWebRequest.Get(url);
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.01f);
            StartCoroutine(CharItemLoad());
        }
        else
        {
            var shopData = JsonConvert.DeserializeObject<ShopItemList>(www.downloadHandler.text);
            shopItemList = shopData;
            ShowALLItemList();
        }
    }
    void ShowALLItemList()
    {
        for(int i = 0;i < shopItemList.Items.Count; i++)
        {
            GameObject item = Instantiate(ItemObject) as GameObject;
            item.transform.SetParent(ItemList.transform, false);
            if (item.GetComponent<ItemInfomation>())
            {
                item.GetComponent<ItemInfomation>().ShopItems = shopItemList.Items[i];
            }
            else if (item.GetComponent<AvataSelect>())
            {
                item.GetComponent<AvataSelect>().ShopItems = shopItemList.Items[i];
            }
          
        }
        
    }

    public void ExitItemList()
    {
        if (ItemList.transform.childCount > 0)
        {
            for (int i = 0; i < ItemList.transform.childCount; i++)
            {
                Destroy(ItemList.transform.GetChild(i).gameObject);
            }
        }
        
    }

}
[System.Serializable]
public class ShopItemList
{
    public int code;
    public string message;
    public int count;
    public List<ShopItems> Items;
}
[System.Serializable]
public class ShopItems
{
    public string code;
    public string type;
    public string name;
    public string category;
    public string sub_category;
    public string placement;
    public string theme;
    public string writer;
    public int peach;
    public int gold;
    public string image;
    public string regist_time;
    public string description;
    public string nickname;
    public string purchase_time;

}