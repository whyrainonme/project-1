using UnityEngine;
using UnityEngine.EventSystems;
public class PinchZoom : MonoBehaviour 
{
    [Header("Camera Zoom In/Out Speed")]
    [SerializeField] private float orthoZoomSpeed = 0.5f; 
    private readonly float Minimum_OrthoSize = 3.5f;
    private readonly float Maximum_OrthoSize = 17f; //origin 7
    private Vector2 nowPos, prePos, movePosDiff;
    Vector3 movePos;
    private Camera Maincamera;
    float Speed = 0.2f;
    Transform playerTr;
    private float lastTouchTime;
    private const float doubleTouchDelay = 0.3f;
    private void Awake()
    {
        Maincamera = Camera.main;
        lastTouchTime = Time.time;
        playerTr = GameObject.Find("Player").GetComponent<Transform>();
    }
    Vector3 preCamPos;
    private void Update()
    {
        if (GameManager.Instance.isMove == true)
        {
            Maincamera.transform.parent = GameObject.Find("Player").gameObject.transform; 
            Maincamera.transform.localPosition = new Vector3(0, 0, -20f);
        }
        if (Input.touchCount > 0)
        {
            if (EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
                return;
            else
            {
                movePosDiff = Vector3.zero;
                if (Input.touchCount == 1 && GameManager.Instance.isMove == false)
                {
                    
                    Touch touch = Input.GetTouch(0);
                    if (touch.phase == TouchPhase.Began)
                    {
                        //if ((Time.time - lastTouchTime < doubleTouchDelay) && touch.phase != TouchPhase.Moved)
                        {
                            //Vector2 touchPos = Camera.main.ScreenToWorldPoint(touch.position);
                            // RaycastHit2D hitInformation = Physics2D.Raycast(touchPos, Camera.main.transform.forward);
                            //  if (hitInformation.collider == null && !GameManager.Instance.isMove)
                            {
                                //   Vector2 vector2 = Maincamera.ScreenToWorldPoint(touch.position);
                                //   PlayerMove.Instance.MoveToPosition(vector2);
                            }

                        }
                        Maincamera.transform.parent = null;
                        prePos = touch.position - touch.deltaPosition;
                        Vector2 pos = Camera.main.ScreenToWorldPoint(touch.position);
                        RaycastHit2D hitInformation = Physics2D.Raycast(pos, Camera.main.transform.forward);
                        var metaverse = new MI_Metaverse();
                        switch (hitInformation.collider.tag)
                        {
                            case "Actor":
                                metaverse.SendArtistInfo(hitInformation.collider.gameObject.name);
                                break;
                            case "Media_V":
                                metaverse.SendMediaData("video", hitInformation.collider.GetComponent<VidesoLoad>().videourl);
                                break;
                            case "Media_P":
                                metaverse.SendMediaData("picture", "");
                                break;
                            case "pictureDL":
                                hitInformation.collider.gameObject.GetComponent<PointerDown>().TouchPicture();
                                break;
                        }
                        switch (hitInformation.collider.name)
                        {
                            case "b_MS":
                                Application.OpenURL("https://lilpop.net/product/detail.html?product_no=74&cate_no=44&display_group=1");
                                break;
                        }

                      
                    }
                    else if (touch.phase == TouchPhase.Moved)
                    {
                        Maincamera.transform.parent = null;
                        nowPos = touch.position - touch.deltaPosition;
                        if (Maincamera.orthographicSize < 5)
                        {
                            Speed = 0.1f;
                        }
                        else if (Maincamera.orthographicSize > 5 && Maincamera.orthographicSize < 11)
                        {
                            Speed = 0.4f;
                        }
                        else if (Maincamera.orthographicSize > 10 && Maincamera.orthographicSize < 15)
                        {
                            Speed = 0.8f;
                        }
                        else
                        {
                            Speed = 1f;
                        }
                        movePosDiff = (Vector2)(prePos - nowPos) * Time.deltaTime * Speed;
          

                        //if (Vector3.Distance(Maincamera.transform.localPosition, playerTr.position) <= 25)
                        {
                            preCamPos = Maincamera.transform.localPosition;
                            Maincamera.transform.Translate(movePosDiff);
                        }
                        //else
                        {
                            //Maincamera.transform.position = preCamPos;
                            //if (Maincamera.transform.position.x - playerTr.position.x >= 7f)
                            //{
                            //    Maincamera.transform.position = new Vector3(7f, Maincamera.transform.position.y, -20f);
                            //}
                            //else if (Maincamera.transform.position.x - playerTr.position.x <= -7f)
                            //{
                            //    Maincamera.transform.position = new Vector3(-7f, Maincamera.transform.position.y, -20f);
                            //}
                            //else if (Maincamera.transform.position.y - playerTr.position.y >= 7f)
                            //{
                            //    Maincamera.transform.position = new Vector3(Maincamera.transform.position.x, 7f, -20f);
                            //}
                            //else if (Maincamera.transform.position.y - playerTr.position.y <= -7f)
                            //{
                            //    Maincamera.transform.position = new Vector3(Maincamera.transform.position.x, -7f, -20f);
                            //}


                        }
                        prePos = touch.position - touch.deltaPosition;

                    }
                    else if (touch.phase == TouchPhase.Ended)
                    {
                        lastTouchTime = Time.time;
                    }
                }
                if (Input.touchCount == 2)
                {
                    Touch touchZero = Input.GetTouch(0);
                    Touch touchOne = Input.GetTouch(1); 
                    Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition; 
                    Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;
                    float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
                    float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;
                    float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;
                    if (deltaMagnitudeDiff != 0f)
                    {
                        Maincamera.orthographicSize += deltaMagnitudeDiff * orthoZoomSpeed * Time.deltaTime;
                        Maincamera.orthographicSize = Mathf.Clamp(Maincamera.orthographicSize, Minimum_OrthoSize, Maximum_OrthoSize);
                    }
                }
            }
        }
    }
    public void OnDrag(PointerEventData eventData)
    {
        Vector2 value = eventData.position - (Vector2)Maincamera.transform.localPosition;
        value = value.normalized;
        movePos = new Vector3(value.x * 100 * Time.deltaTime, value.y * Time.deltaTime);
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        Maincamera.transform.localPosition = new Vector3(0, 0, -20f);
    }
}
