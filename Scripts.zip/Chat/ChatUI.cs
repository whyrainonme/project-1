using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatUI : MonoBehaviour
{
    WebSocketConnect webSocketConnect;
    public ChatManager ChatManager;
    public ScrollRect worldView,localView;
    private void Awake()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
    }
    private void OnEnable()
    {
        if (webSocketConnect.area == "" || webSocketConnect.area == null)
        {
            worldView.GetComponent<ScrollRect>().normalizedPosition = new Vector2(0, 0);
            ChatManager.WorldChat();
        }
        else
        {
            localView.GetComponent<ScrollRect>().normalizedPosition = new Vector2(0, 0);
            ChatManager.LocalChat();
        }
      
    }

 
}
