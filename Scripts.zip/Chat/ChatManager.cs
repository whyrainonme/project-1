using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatManager : MonoBehaviour
{
   
    public InputField inputField;
    public Text worldChatText, localChatText;
    public GameObject worldChat, localChat;
    public Image worldIcon, localIcon;
    public ScrollRect scrollView;
    GameObject playerChatBox;
    WebSocketConnect webSocketConnect;
    void Start()
    {
        inputField.onEndEdit.AddListener(delegate { LockInput(inputField); });
        inputField.onSubmit.AddListener(delegate { LockInput(inputField); });

        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        GameObject playerCV = GameObject.Find("Player").gameObject.transform.Find("PlayerCanvas").gameObject;
        playerChatBox = playerCV.transform.Find("ChatBox").gameObject;
        StartCoroutine(UpdateChat());
    }
    IEnumerator UpdateChat()
    {
        if (webSocketConnect.chatList.chat.Count > 0)
        {
            for (int i = 0; i < webSocketConnect.chatList.chat.Count; i++)
            {
                if (webSocketConnect.chatList.chat[i].area == "")
                {
                    if (webSocketConnect.chatList.chat[i].id == webSocketConnect.responeseLogin.id)
                    {
                        //worldChatText.alignment = TextAnchor.MiddleRight;
                        worldChatText.text +=
                             "<color=#FFF612>" + webSocketConnect.chatList.chat[i].nickname + " : " + webSocketConnect.chatList.chat[i].message + "</color>" + "\n" ;
                    }
                    else
                    {
                        worldChatText.text +=
                        "<color=#FFFFFF>" + webSocketConnect.chatList.chat[i].nickname + " : "+  webSocketConnect.chatList.chat[i].message + "</color>" + "\n";
                        GameObject.Find(webSocketConnect.chatList.chat[i].id).GetComponent<UsersMove>().chatString = webSocketConnect.chatList.chat[i].message;
                    }
                    //scrollView.verticalNormalizedPosition = 0;
                    worldChat.GetComponent<ScrollRect>().normalizedPosition = new Vector2(0, 0);
                }
                else if (webSocketConnect.chatList.chat[i].area == webSocketConnect.area &&
                   webSocketConnect.chatList.map == webSocketConnect.sceneName)
                {
                    if (webSocketConnect.chatList.chat[i].id == webSocketConnect.responeseLogin.id)
                    {
                        //worldChatText.alignment = TextAnchor.MiddleRight;
                        localChatText.text +=
                             "<color=#FFF612>" + webSocketConnect.chatList.chat[i].nickname + " : " + webSocketConnect.chatList.chat[i].message + "</color>" + "\n" ;
                    }
                    else
                    {
                        localChatText.text +=
                       "<color=#FFFFFF>" + webSocketConnect.chatList.chat[i].nickname + " : " + webSocketConnect.chatList.chat[i].message + "</color>" + "\n";
                        GameObject.Find(webSocketConnect.chatList.chat[i].id).GetComponent<UsersMove>().chatString = webSocketConnect.chatList.chat[i].message;
                    }
                    //scrollView.verticalNormalizedPosition = 0;
                    localChat.GetComponent<ScrollRect>().normalizedPosition = new Vector2(0, 0);
                }
              
            }
            // webSocketConnect.chatList.chat.Clear();
            //나 자신이 아니면 찾아서 말풍선 활성화
            
            yield return new WaitForSeconds(0.2f);
            webSocketConnect.chatList.chat.Clear();

        }
        yield return new WaitForSeconds(0.2f);
            StartCoroutine(UpdateChat());
    }
    public void WorldChat()
    {
        localChat.SetActive(false);
        worldChat.SetActive(true);
        localIcon.color = Color.gray;
        worldIcon.color = Color.white;
    }
    public void LocalChat()
    {
        worldChat.SetActive(false);
        localChat.SetActive(true);
        localIcon.color = Color.white;
        worldIcon.color = Color.gray;
    }
    public void SendChatMessage()
    {
        string t = inputField.text;

        if (t.Length > 0)
        {
            if(t.Length > 15)
            {
                string result = "";
                int indexStart = 0, indexEnd = 0;
                int iSplit = 16, totalLength = t.Length, forCount = totalLength / iSplit;
                if (totalLength > 15)
                {
                    for (int i = 0; i < forCount + 1; i++)
                    {
                        if (totalLength < indexStart + iSplit)
                        {
                            indexEnd = totalLength - indexStart;
                        }
                        else
                        {
                            indexEnd = t.Substring(indexStart, iSplit).LastIndexOf("");
                        }
                        result += t.Substring(indexStart, indexEnd) + "\r\n";
                        indexStart += indexEnd;
                    }
                    t = result.Substring(0, result.Length - 2);

                }
                else
                {
                   t =  result;
                }

            }
            playerChatBox.transform.Find("Text").GetComponent<Text>().text = t;
            playerChatBox.SetActive(true);

            webSocketConnect.chatMessage = t;
            webSocketConnect.sendMessage(4);

            inputField.text = "";
           // scrollView.GetComponent<ScrollRect>().normalizedPosition = new Vector2(0, 0);/////////
            StartCoroutine(CloseChatPOP());
        }
    }
   IEnumerator CloseChatPOP()
    {
        yield return new WaitForSeconds(2f);
        //if (inputField.text == "")//////////
        {
            playerChatBox.SetActive(false);
        }
    }
        

    void LockInput(InputField input)
    {
        if (input.text.Length != 0)
        {
            SendChatMessage();
        }
       
    }
}
