using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ProjectorUI : MonoBehaviour
{
    public ADfontIMG[] fontSprites, fontOffSprites;
    public GameObject[] charSprites;
    // public GameObject noticeUI, confirmUI;
    // public Text noticetxt, confirmtxt;
    // public InputField projectorInputField;
    IEnumerator coroutine;
    WebSocketConnect webSocketConnect;
    public string id;
    public string t = " WELCOME   LILPOP    WORLD!";
    void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        coroutine = (TextAnim());
        StartCoroutine(TextUpdate());
        StartCoroutine(coroutine);
    }

    IEnumerator TextUpdate()
    {
        yield return new WaitForSeconds(0.3f);

        if ( !webSocketConnect.isLoading)
        {
            for (int i = 0; i < webSocketConnect.rcevMapInfo.text.Length; i++)
            {
                if (webSocketConnect.rcevMapInfo.text[i].id == id && webSocketConnect.rcevMapInfo.text[i].value != t)
                {
                    t = webSocketConnect.rcevMapInfo.text[i].value;
                    t = t.ToUpper();
                }
            }
        }

        StartCoroutine(TextUpdate());
    }
    //projectorInputField.text = projectorInputField.text.ToUpper();
    //foreach (char ch in projectorInputField.text)
    //{
    //    int value = Convert.ToInt32(ch);
    //    if ((value < 65 || value > 90) &&((value < 48 || value > 57))) //범위 외에서
    //    {
    //        //지정된 특수문자를 사용했다면
    //        if (ch.ToString() != "." && ch.ToString() != (",") && ch.ToString() != ("!")
    //               && ch.ToString() != ("?") && ch.ToString() != ("♡") && ch.ToString() != ("♥︎")
    //               && ch.ToString() != ("★") && ch.ToString() != ("☆") && ch.ToString() != (" "))// && ch.ToString() != ("\n"))
    //        {
    //            projectorInputField.text = projectorInputField.text.Replace(ch.ToString(), "");

    //            NoticeOpen("영자 입력만 가능합니다");
    //            projectorInputField.touchScreenKeyboard.active = false;
    //            confirmUI.SetActive(false);
    //        }
    //    }
    //}


    //void NoticeOpen(string str)
    //{
    //    noticeUI.SetActive(true);
    //    noticetxt.text = str;
    //}
    //public void NoticeConfirmClose()
    //{
    //    noticeUI.SetActive(false);
    //    confirmUI.SetActive(false);
    //}

    //public void Complete() //완료하기
    //{
    //    StopCoroutine(coroutine);
    //    //전광판에 하나씩 띄워주기 , (서버에 보내는 것으로 수정 )
    //    string text = projectorInputField.text;
    //    int length = text.Length;
    //    for (int i = 0; i < charSprites.Length; i++)
    //    {
    //        charSprites[i].SetActive(false);
    //    }

    //    for (int i = 0; i < length; i++)
    //    {
    //        for(int j =0; j < fontSprites.Length; j++)
    //        {
    //            if (text[i].ToString() == fontSprites[j].spriteName)
    //            {
    //                charSprites[i].GetComponent<SpriteRenderer>().sprite
    //                    = fontSprites[j].sprite;
    //                charSprites[i].SetActive(true);
    //            }
    //        }
    //    }


    //    coroutine =  (TextAnim());
    //    StartCoroutine(coroutine);
    //    projectorInputField.text = "";
    //    NoticeConfirmClose();
    //}
    IEnumerator TextAnim()
    {
        //글자가 수정되었으면 초기화 해주어야 함
        //t = webSocketConnect.rcevMapInfo.text[0].value;
        int rand = UnityEngine.Random.Range(0, 2);
        yield return new WaitForSeconds(3f);

        //for (int i = 0; i < t.Length; i++)
        //{
        //    for (int j = 0; j < fontSprites.Length; j++)
        //    {
        //        if (t[i].ToString() == fontSprites[j].spriteName)
        //        {
        //            charSprites[i].GetComponent<SpriteRenderer>().sprite
        //                = fontOffSprites[j].sprite;
        //        }
        //    }
        //}
        //ChangeImage(0, t.Length, true, t);
        for (int i = 0; i < charSprites.Length; i++)
        {
            charSprites[i].GetComponent<SpriteRenderer>().sprite
                            = null;
        }
        ChangeImage(0, t.Length, true, t);
        yield return new WaitForSeconds(0.15f);
        switch (rand)
        {
            case 0:
                //글자수에 따라 initIndex가 달라져야함
                if (t.Length <= 10) //한줄일때
                {
                    ChangeImage(0, t.Length, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(0, t.Length, true, t);
                }
                else if (t.Length > 10 && t.Length <= 20) //두줄일땖
                {
                    ChangeImage(0, 10, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(10, t.Length, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(0, t.Length, true, t);
                }
                else
                {
                    ChangeImage(0, 10, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(10, 20, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(20, t.Length, false, t);
                    yield return new WaitForSeconds(0.15f);
                    ChangeImage(0, t.Length, true, t);
                }
                break;
            case 1:
                ChangeImage(0, t.Length, false, t);
                yield return new WaitForSeconds(0.15f);
                ChangeImage(0, t.Length, true, t);
                yield return new WaitForSeconds(0.15f);
                ChangeImage(0, t.Length, false, t);
                yield return new WaitForSeconds(0.15f);
                ChangeImage(0, t.Length, true, t);
                yield return new WaitForSeconds(0.15f);
                break;
        }

        coroutine = (TextAnim());
        StartCoroutine(coroutine);
    }
    void ChangeImage(int initIndex, int length, bool onOff, string t)
    {

        if (onOff)
        {

            for (int i = initIndex; i < length; i++)
            {
                for (int j = 0; j < fontSprites.Length; j++)
                {
                    if (t[i].ToString() == fontSprites[j].spriteName)
                    {
                        charSprites[i].GetComponent<SpriteRenderer>().sprite
                            = fontSprites[j].sprite;
                    }
                }
            }

        }
        else
        {

            for (int i = initIndex; i < length; i++)
            {
                for (int j = 0; j < fontSprites.Length; j++)
                {
                    if (t[i].ToString() == fontOffSprites[j].spriteName)
                    {
                        charSprites[i].GetComponent<SpriteRenderer>().sprite
                            = fontOffSprites[j].sprite;
                    }

                }
            }
        }

    }
    //List<char> charactors;
    //public void SendText()
    //{

    //    string result ="";
    //    //10줄에 한번씩 엔터 생성
    //    string sendT = projectorInputField.text;

    //    int indexStart = 0, indexEnd = 0;
    //    int iSplit = 11, totalLength = sendT.Length, forCount = totalLength / iSplit;
    //    if (totalLength > 10)
    //    {
    //        for (int i = 0; i < forCount + 1; i++)
    //        {
    //            if (totalLength < indexStart + iSplit)
    //            {
    //                indexEnd = totalLength - indexStart;
    //            }
    //            else
    //            {
    //                indexEnd = sendT.Substring(indexStart, iSplit).LastIndexOf("");
    //            }
    //            result += sendT.Substring(indexStart, indexEnd) + "\r\n";
    //            indexStart += indexEnd;
    //        }
    //        result = result.Substring(0, result.Length - 2);

    //    }
    //    else
    //    {
    //        result = sendT;
    //    }
    //    confirmtxt.text = result;
    //    confirmUI.SetActive(true);
    //}
}
[System.Serializable]
public class ADfontIMG
{
    public string spriteName;
    public Sprite sprite;
}