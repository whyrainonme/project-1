using System.Collections;
using UnityEngine;
using MyDefines.Enum;
using System.Collections.Generic;
using UnityEngine.Tilemaps;
using UnityEngine.UI;
using static UnityEngine.UIElements.UxmlAttributeDescription;
//using static UnityEditor.PlayerSettings;


public class PlayerMove : MonoBehaviour
{
    //[System.NonSerialized]
    Animator animator;
    public CharactorAnims CharactorAnims;
    public static PlayerMove Instance { get; private set; }
    public Player_CollisionState state;
    public float speed;
   
    public bool IsAbleToMove = true;

    public Player_Dir CurrentDir;
     Joystick joystick;
   
    WebSocketConnect webSocketConnect;
    PlayerEnterArea playerEnterArea;
    public float jumpPower;
    Camera cam;
    [System.NonSerialized]
    public SpriteRenderer render;
    public GameObject headIcon;
    Text postxt;
    GameObject map, charactorEdit;
    public Vector3 sitPos;
    GameObject buttonpanel;
    public bool isMove, isJumping , isSit, isTalk;
    bool walkingAnim = false;
    bool selectedChar;
    void Awake()
    {
        if (Instance)
        {
            Destroy(this.gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(this.gameObject);
        state = Player_CollisionState.None;
        joystick = FindObjectOfType<Joystick>();
        CurrentDir = Player_Dir.FL;
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        playerEnterArea = GameObject.Find("Player").GetComponent<PlayerEnterArea>();
        render = GetComponent<SpriteRenderer>();
        postxt = GameObject.Find("MainCanvas").transform.Find("pos").GetComponent<Text>();
        buttonpanel = GameObject.Find("MainCanvas").transform.Find("ButtonPanel").gameObject;
        map = buttonpanel.transform.Find("Button4").gameObject;
        charactorEdit = buttonpanel.transform.Find("CharactorEdit").gameObject;
        animator = GetComponent<Animator>();
        StartCoroutine(AnimStateCheck());
    }
    IEnumerator AnimStateCheck()
    {
        selectedChar = buttonpanel.GetComponent<SelectCharactor>().selectedChar;
        if (selectedChar)
        {
            switch (CurrentDir)
            {
                case Player_Dir.FL:
                    render.flipX = false;
                    animator.SetFloat("Blend", 0);
                    break;
                case Player_Dir.BR:
                    render.flipX = false;
                    animator.SetFloat("Blend", 1);
                    break;
                case Player_Dir.BL:
                    render.flipX = true;
                    animator.SetFloat("Blend", 1);
                    break;
                case Player_Dir.FR:
                    render.flipX = true;
                    animator.SetFloat("Blend", 0);
                    break;
            }
            if (isJumping)
            {
                Jump();
            }
            else if (isSit)
            {
                animator.SetBool("SIT", true);
                if (isTalk)
                {
                    animator.SetTrigger("TALK");
                }
            }
            else
            {
                if (isMove)
                {
                    animator.SetBool("WALK", true);
                }
                else
                {
                    animator.SetBool("WALK", false);
                    if (isTalk)
                    {
                        animator.SetTrigger("TALK");
                    }
                }
            }
            yield return new WaitForSeconds(0.2f);
            StartCoroutine(AnimStateCheck());
        }
        else
        {
            yield return new WaitForSeconds(1f);
            StartCoroutine(AnimStateCheck());
        }
    }

    void FixedUpdate()
    {
        postxt.text = transform.position.ToString();
        if (IsAbleToMove == false) return;// || state == Player_CollisionState.UFO)
        if (!isJumping)
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
        }
        if (joystick.isInput && !isJumping && !isSit)
        {
            isMove = true;
            MoveControl(joystick.inputVector);
        }
        else
        {
            isMove = false;
        }
        if (webSocketConnect.responeseLogin.user_type == "artist") //아티스트면 
        {
            headIcon.SetActive(true); //추후 캐릭터 파일 오면 이후로직 수정 
        }
        else
        {
            headIcon.SetActive(false);
        }
    }
    Vector3 originPos;
    Sprite currSprite;
    public void Jump()
    {
        if (isJumping || isMove) return; 
        else
        {
            isJumping = true;
            animator.SetTrigger("JUMP"); 
            originPos = transform.position;
            cam = Camera.main;
            cam.transform.parent = null;

            this.gameObject.GetComponent<Rigidbody2D>().gravityScale = 1;
            this.gameObject.GetComponent<Rigidbody2D>().AddForce(new Vector3(0, jumpPower, 0));
            GetComponent<BoxCollider2D>().isTrigger = true;
            StartCoroutine(Jump1());
        }
    }
    IEnumerator Jump1()
    {
        yield return new WaitForSeconds(0.4f);
        cam.transform.parent = this.gameObject.transform;
        cam.transform.localPosition = new Vector3(0, 0, -20f);
        this.gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
        
        isJumping = false;
        transform.position = originPos;
        GetComponent<BoxCollider2D>().isTrigger = false;
        if (webSocketConnect.socketState)
        {
            webSocketConnect.SendActionMessage("jump", CurrentDir.ToString(), transform.position);
        }
    }

  
   public float moveAnimSpeed = 0.2f, idleSpeed = 0.5f;


    public void PlayerInfo()
    {
        var metaverse = new MI_Metaverse();
        WebSocketConnect webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        string id = webSocketConnect.responeseLogin.id;
        // Debug.Log(id + "전송 ");
        metaverse.SendUserInfo(id);
    }
    public void SitAnimation(SitAnim.rotateDir rotateDir)
    {
        isSit = true;
        joystick.canvasGroup.alpha = 0.5f;
        joystick.canvasGroup.blocksRaycasts = false;
        map.GetComponent<CanvasGroup>().alpha = 0.5f;
        map.GetComponent<CanvasGroup>().blocksRaycasts = false;
        charactorEdit.GetComponent<CanvasGroup>().alpha = 0.5f;
        charactorEdit.GetComponent<CanvasGroup>().blocksRaycasts = false;
        transform.position = sitPos;
        switch (rotateDir)
        {
            case SitAnim.rotateDir.FL:
                CurrentDir = Player_Dir.FL;
                break;
            case SitAnim.rotateDir.FR:
                CurrentDir = Player_Dir.FR;
                break;
            case SitAnim.rotateDir.BR:
                CurrentDir = Player_Dir.BR;
                break;
            case SitAnim.rotateDir.BL:
                CurrentDir = Player_Dir.BL;
                break;
        }
        webSocketConnect.SendActionMessage("sit","down", sitPos);
    }
    public void SitUpAnimation(SitAnim.rotateDir rotateDir)
    {
        joystick.canvasGroup.alpha = 1f;
        joystick.canvasGroup.blocksRaycasts = true;
        map.GetComponent<CanvasGroup>().alpha = 1f;
        map.GetComponent<CanvasGroup>().blocksRaycasts = true;
        charactorEdit.GetComponent<CanvasGroup>().alpha = 1f;
        charactorEdit.GetComponent<CanvasGroup>().blocksRaycasts = true;
        transform.position = sitPos; //위치 전true
        switch (rotateDir)
        {
            case SitAnim.rotateDir.FL:
                CurrentDir = Player_Dir.FL;
                break;
            case SitAnim.rotateDir.FR:
                CurrentDir = Player_Dir.FR;
                break;
            case SitAnim.rotateDir.BR:
                CurrentDir = Player_Dir.BR;
                break;
            case SitAnim.rotateDir.BL:
                CurrentDir = Player_Dir.BL;
                break;
        }
        isSit = false;
        animator.SetBool("SIT", false);
        webSocketConnect.SendActionMessage("sit", "up", sitPos);
        webSocketConnect.sendMessage(1);
    }
    private void MoveControl(Vector2 dir)
    {
        Player_Dir PrevDir = CurrentDir;
        if (dir.x > 0f && dir.y > 0f)
            CurrentDir = Player_Dir.BR;
        else if (dir.x < 0f && dir.y > 0f)
            CurrentDir = Player_Dir.BL;
        else if (dir.x > 0f && dir.y < 0f)
            CurrentDir = Player_Dir.FR;
        else if (dir.x < 0f && dir.y < 0f)
            CurrentDir = Player_Dir.FL;
        Vector3 moveAmount = dir * speed * Time.deltaTime;
        this.transform.position += moveAmount;
    }
    

    public void SetPositionBySceneType(Scene_Type type, Vector3 pos, Scene_Type PreType = Scene_Type.Max, string selectMap = "")
    {
        state = Player_CollisionState.None;
        if (GameManager.Instance.lastPOS != Vector2.zero)
        {
            transform.position = GameManager.Instance.lastPOS;
            GameManager.Instance.lastPOS = Vector2.zero;
        }
        else
        {
            switch (type)
            {
                case Scene_Type.WolrdMap:
                    if (PreType == Scene_Type.party)
                    {
                        webSocketConnect.area = "";
                        playerEnterArea.area = "";
                    }
                    if (selectMap != "")
                    {
                        transform.position = pos;
                    }
                  
                    else
                    {
                        if (PreType == Scene_Type.SangsangMadang)   // ��󸶴翡�� ������ ��
                        {
                            transform.position = new Vector3(-28.55f, -12.22f);
                        }
                        else if (PreType == Scene_Type.party)
                        {
                            this.transform.position = new Vector3(5.31f, -10.22f);
                        }
                        else if (PreType == Scene_Type.WD_fan)
                        {
                            this.transform.position = new Vector3(8.54f, -9.2f);
                        }
                        else if (PreType == Scene_Type.WD_stage)
                        {
                            this.transform.position = new Vector3(-0.45f, -8.48f);
                        }
                        else if (PreType == Scene_Type.HongDea)
                        {
                            this.transform.position = new Vector3(-28.55f, -12.22f);
                        }
                        else if (PreType == Scene_Type.default1)
                        {
                            this.transform.position = new Vector3(-31.2f, -23.76f);
                        }
                        else if (PreType == Scene_Type.default2)
                        {
                            this.transform.position = new Vector3(-27.11f, -20.9f);
                        }
                        else if (PreType == Scene_Type.DrinkLine)
                        {
                            this.transform.position = new Vector3(30.46f, 5.46f);
                        }
                        else if (PreType == Scene_Type.KL)
                        {
                            this.transform.position = new Vector3(-87.4f, 8.7f);
                        }
                        else if (PreType == Scene_Type.NEMO)
                        {
                            this.transform.position = new Vector3(-16.55f, -21.04f);
                        }
                        else if (PreType == Scene_Type.ODC)
                        {
                            this.transform.position = new Vector3(30.6f, -6f);
                        }
                        else if (PreType == Scene_Type.Misun)
                        {
                            this.transform.position = new Vector3(-37.5f, -32.7f);
                        }
                        else if (PreType == Scene_Type.ZAri)
                        {
                            this.transform.position = new Vector3(17.62f,-15.22f);
                        }
                        else
                        {
                            this.transform.position = new Vector3(-20f, -7f);
                        }
                    }
                    break;

                case Scene_Type.WD_fan:
                    if (PreType == Scene_Type.WD_fanRoom)
                    {
                        this.transform.position = new Vector3(-7.7f, -1.22f);
                    }
                    else
                    {
                        this.transform.position = new Vector3(-2.3f, -5.33f);
                    }
                    break;
                case Scene_Type.HongDea:
                    transform.position = new Vector3(-3.36f, -1.16f);
                    break;
                case Scene_Type.My_Room:
                    this.transform.position = Vector2.zero;
                    break;
                default:
                    transform.position = GameObject.FindGameObjectWithTag("portal").gameObject.transform.position;
                    break;
            }
           // webSocketConnect.SendPosition(transform.position, CurrentDir.ToString());
        }
    }
  
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "SBS")
        {
            state = Player_CollisionState.SBS;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        if (collision.gameObject.name == "Radio")
        {
            //state = Player_CollisionState.Radio;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //collision.gameObject.transform.Find("icon_interact2").gameObject.SetActive(true);
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ZangAri")
        {
            state = Player_CollisionState.ZAri;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Misun")
        {
            state = Player_CollisionState.Misun;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ODC")
        {
            state = Player_CollisionState.ODC;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "NEMO")
        {
            state = Player_CollisionState.NEMO;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "DrinkLine")
        {
            state = Player_CollisionState.DrinkLine;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "KL")
        {
            state = Player_CollisionState.KL;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                  .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "st_HZoddmonster")
        {
            state = Player_CollisionState.st_HZoddmonster;
            collision.gameObject.transform.Find("Effect").GetComponentInChildren<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ADfont")
        {
            //state = Player_CollisionState.adfont;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
        }
        else if (collision.gameObject.name == "Party")
        {
            state = Player_CollisionState.party;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "fanRoom")
        {
            state = Player_CollisionState.WD_fanRoom;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "default1")
        {
            state = Player_CollisionState.default1;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "default2")
        {
            state = Player_CollisionState.default2;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                  .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Diary")
        {
            //state = Player_CollisionState.Diary;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "HongDea")
        {
            state = Player_CollisionState.HongDea;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ArtistConnect")
        {
            //state = Player_CollisionState.ArtistConnect;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "wildwild")
        {
            state = Player_CollisionState.wildwild;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "WD_fan")
        {
            state = Player_CollisionState.WD_fan;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "WD_Stage")
        {
            state = Player_CollisionState.WD_Stage;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Koex")
        {
            state = Player_CollisionState.Koex;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "SangsangMadang")
        {
            state = Player_CollisionState.SangsangMadang;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        //else if (collision.gameObject.name == "SubwayZone")
        //{
        //    state = Player_CollisionState.SubwayZone;
        //    collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
        //    GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        //}
        else if (collision.gameObject.name == "Cam")
        {
            //state = Player_CollisionState.Cam;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Web")
        {
            //state = Player_CollisionState.Web;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Game1")
        {
            state = Player_CollisionState.Game1;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Streaming")
        {
            //state = Player_CollisionState.Streaming;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.name == "SBS")
        {
            state = Player_CollisionState.SBS;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        if (collision.gameObject.name == "Radio")
        {
            //state = Player_CollisionState.Radio;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //collision.gameObject.transform.Find("icon_interact2").gameObject.SetActive(true);
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ZangAri")
        {
            state = Player_CollisionState.ZAri;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Misun")
        {
            state = Player_CollisionState.Misun;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ODC")
        {
            state = Player_CollisionState.ODC;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "NEMO")
        {
            state = Player_CollisionState.NEMO;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "DrinkLine")
        {
            state = Player_CollisionState.DrinkLine;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "KL")
        {
            state = Player_CollisionState.KL;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                  .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "st_HZoddmonster")
        {
            state = Player_CollisionState.st_HZoddmonster;
            collision.gameObject.transform.Find("Effect").GetComponentInChildren<SpriteRenderer>().color = new Vector4(1, 1, 1, 1);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ADfont")
        {
            //state = Player_CollisionState.adfont;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;

        }
        else if (collision.gameObject.name == "Party")
        {
            state = Player_CollisionState.party;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "fanRoom")
        {
            state = Player_CollisionState.WD_fanRoom;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "default1")
        {
            state = Player_CollisionState.default1;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
               .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "default2")
        {
            state = Player_CollisionState.default2;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                  .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Diary")
        {
            //state = Player_CollisionState.Diary;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "HongDea")
        {
            state = Player_CollisionState.HongDea;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "ArtistConnect")
        {
            //state = Player_CollisionState.ArtistConnect;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "wildwild")
        {
            state = Player_CollisionState.wildwild;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "WD_fan")
        {
            state = Player_CollisionState.WD_fan;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "WD_Stage")
        {
            state = Player_CollisionState.WD_Stage;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Koex")
        {
            state = Player_CollisionState.Koex;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);

        }
        else if (collision.gameObject.name == "SangsangMadang")
        {
            state = Player_CollisionState.SangsangMadang;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
       
        else if (collision.gameObject.name == "Cam")
        {
            //state = Player_CollisionState.Cam;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Web")
        {
            //state = Player_CollisionState.Web;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Game1")
        {
            state = Player_CollisionState.Game1;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                           .SetBool("enter", true);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(true);
            GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
        else if (collision.gameObject.name == "Streaming")
        {
            //state = Player_CollisionState.Streaming;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = BoxColor;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, true);
        }
    }
    
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "SBS")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
           // GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        if (collision.gameObject.name == "wildwild")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
            // GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "ZangAri")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
            //  GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Misun")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
            //  GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "ODC")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
            //  GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "NEMO")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
         //   GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "DrinkLine")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
      //      GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "KL")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                         .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
       //     GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "st_HZoddmonster")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponentInChildren<SpriteRenderer>().color = new Vector4(1, 1, 1, 0.4f);
            collision.gameObject.GetComponent<Animator>().SetBool("dance", false);
         //   GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        
        else if (collision.gameObject.name == "fanRoom")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
         //   GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);

        }
      
        else if (collision.gameObject.name == "ADfont")
        {
            state = Player_CollisionState.None;
            //collision.gameObject.GetComponent<SpriteRenderer>().color = Color.clear;
          //  GameObject.Find("MainCanvas").transform.Find("Projector_InputField").GetComponent<CanvasGroup>().alpha = 0f;
          //  GameObject.Find("MainCanvas").transform.Find("Projector_InputField").GetComponent<CanvasGroup>().interactable = false;
        }
        else if (collision.gameObject.name == "Party")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
         //   GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "default1")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
       //     GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "default2")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
       //     GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Diary")
        {
            state = Player_CollisionState.None;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "HongDea")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
     //       GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "ArtistConnect")
        {
            state = Player_CollisionState.None;
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Radio")
        {
            state = Player_CollisionState.None;
            //collision.gameObject.transform.Find("icon_interact2").gameObject.SetActive(false);
            //if (GameObject.Find("Radio").GetComponent<RadioScript>().audio.clip == GameObject.Find("Radio").GetComponent<RadioScript>().sound[1]) //라디오 실행중이면
            //{
            //    GameObject.Find("Radio").GetComponent<RadioScript>().ExitRadio();
            //}
            //GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "WD_fan")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
       //     GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "WD_Stage")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
       //     GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Koex")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
        //    GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "SangsangMadang")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
        //    GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        //else if (collision.gameObject.name == "SubwayZone")
        //{
        //    state = Player_CollisionState.None;
        //    GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        //}
        else if (collision.gameObject.name == "Cam")
        {
            state = Player_CollisionState.None;
     //       GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Web")
        {
            state = Player_CollisionState.None;
     //       GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Game1")
        {
            state = Player_CollisionState.None;
            collision.gameObject.transform.Find("Effect").GetComponent<Animator>()
                                    .SetBool("enter", false);
            transform.Find("PlayerCanvas").transform.Find("EnterIcon").gameObject.SetActive(false);
     //       GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
        else if (collision.gameObject.name == "Streaming")
        {
            state = Player_CollisionState.None;
    //        GameObject.Find("MainCanvas").GetComponent<MainCanvas>().ButtonsCanvasGroup(1, false);
        }
    }
 
}
