using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Joystick : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler 
{
    [SerializeField] private RectTransform lever;
    [SerializeField] private Canvas mainCanvas;

    private RectTransform rectTransform;
    public CanvasGroup canvasGroup;
    public Vector2 inputVector;
    private float leverRange;
    public bool isInput;

    private void Awake() 
    {
        canvasGroup = GetComponent<CanvasGroup>();
        rectTransform = GetComponent<RectTransform>();
        leverRange = rectTransform.sizeDelta.x * 0.5f;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        isInput = true;
        ControlJoystickLever(eventData);
     
    }

    public void OnDrag(PointerEventData eventData)
    {
       
        ControlJoystickLever(eventData);  
    }

    public void ControlJoystickLever(PointerEventData eventData)
    {
        GameManager.Instance.isMove = true;
        Vector2 vec = (eventData.position - (Vector2)rectTransform.position);
        Vector2 dir = vec.normalized;
        float distance = vec.magnitude;

        if(distance <= leverRange)
            lever.position = eventData.position;
        else
            lever.anchoredPosition = dir * leverRange;

        inputVector = dir;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        WebSocketConnect webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        if (webSocketConnect.socketState)
        {
            webSocketConnect.sendMessage(1);
        }
        GameManager.Instance.isMove = false;
        lever.anchoredPosition = Vector2.zero;
        isInput = false;
    }

}