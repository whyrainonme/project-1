using System.Collections;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using UnityEngine;
using UnityEngine.Android;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

public class PlayerEnterArea : MonoBehaviour
{
    WebSocketConnect webSocketConnect;
    MI_Metaverse MI_Metaverse;
    public LoadWebRTC loadWebRTC;
    GameObject panel, maxPOP;
    public string area;
    public GameObject enterEffect, voiceEffect;
    PlayerMove playerMove;
    void Start()
    {
        webSocketConnect = GameObject.Find("WebSocketClient").GetComponent<WebSocketConnect>();
        MI_Metaverse = new MI_Metaverse();
        panel = GameObject.Find("MainCanvas").transform.Find("ButtonPanel").gameObject;
        maxPOP = panel.transform.Find("MaxPOP").gameObject;
        playerMove = GetComponent<PlayerMove>();
    }

    IEnumerator GetText(string coll, bool mic, Collider2D collision)
    {
        string url;
        if (webSocketConnect.testMode)
        {
            url = "https://dev.lilpop.kr/api/v1/metaverse/webrtc" + "?map=" + SceneType() + "&area=" + coll;
        }
        else
        {
            url = "https://api.lilpop.kr/v1/metaverse/webrtc" + "?map=" + SceneType() + "&area=" + coll;
        }

        UnityWebRequest www = UnityWebRequest.Get(url);
        string value = webSocketConnect.responeseLogin.access_token;
        www.SetRequestHeader("Authorization", "Bearer " + value);

        yield return www.SendWebRequest();

        if (www.isNetworkError || www.isHttpError)
        {
            yield return new WaitForSeconds(0.1f);
            StartCoroutine(GetText(coll, mic, collision));
        }
        else
        {
            var loadWebRTCData = JsonConvert.DeserializeObject<LoadWebRTC>(www.downloadHandler.text);
            loadWebRTC = loadWebRTCData;
            StartCoroutine(ConnectWeb(coll, mic, collision));
        }
    }
    IEnumerator ConnectWeb(string coll, bool mic, Collider2D collision)
    {
        if (loadWebRTC.max_user != 0)
        {
            if (loadWebRTC.curr_user >= loadWebRTC.max_user)
            {
                fullArea = true;
                collision.isTrigger = false;
                maxPOP.SetActive(true);
                loadWebRTC = null;
                Invoke("ExitMaxPOP", 1.5f);
            }
            else
            {
                panel.transform.Find("mic").GetComponent<MicOnOff>().MicState(true);
                panel.transform.Find("mic").gameObject.SetActive(true);
                fullArea = false;
                MI_Metaverse.EnterRTC(SceneType(), coll, mic);
                area = collision.name;
                webSocketConnect.area = collision.gameObject.name;
                var sprites = GameObject.FindObjectsOfType<SpriteRenderer>();
                var tiles = GameObject.FindObjectsOfType<Tilemap>();

                var parent = collision.gameObject.transform.parent;
                var areaSprite = parent.GetComponentsInChildren<SpriteRenderer>();
                var areaTilemap = parent.GetComponentsInChildren<TilemapRenderer>();
                //GameObject.FindGameObjectsWithTag(collision.name);

                var IMPASSABLE = GameObject.FindGameObjectWithTag("IMPASSABLE");
                var player = GameObject.FindGameObjectWithTag("Player");
                var users = GameObject.FindGameObjectsWithTag("users");

                foreach (var otherSP in sprites)
                {
                    otherSP.color = new Vector4(0.7f, 0.7f, 0.7f, 1f);
                }
                foreach (var otherTE in tiles)
                {
                    otherTE.color = new Vector4(0.7f, 0.7f, 0.7f, 1f);
                }
                foreach (var otherTG in areaTilemap)
                {
                    otherTG.gameObject.GetComponent<Tilemap>().color = Color.white;
                }
                foreach (var otherTG in areaSprite)
                {
                    otherTG.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                }
                if (IMPASSABLE.GetComponent<Tilemap>())
                {
                    IMPASSABLE.GetComponent<Tilemap>().color = new Vector4(0, 0, 0, 0);
                }
                else if (IMPASSABLE.GetComponent<SpriteRenderer>())
                {
                    IMPASSABLE.GetComponent<SpriteRenderer>().color = new Vector4(0, 0, 0, 0);
                }
                player.GetComponent<SpriteRenderer>().color = Color.white;
                voiceEffect.GetComponent<SpriteRenderer>().color = Color.white;
                enterEffect.GetComponent<SpriteRenderer>().color = Color.white;

            }
        }
        else
        {
            //ㅈㅐ연결시도
            yield return new WaitForSeconds(0.1f);
            StartCoroutine(ConnectWeb(coll, mic, collision));
        }
    }
    private void Update()
    {
        var users = GameObject.FindGameObjectsWithTag("users");
        foreach (var areauser in users)
        {
            if (area != "")
            {
                if (areauser.GetComponent<UsersMove>().state == area)//area 안에 있는 user 라면 
                {
                    areauser.GetComponent<SpriteRenderer>().color = Color.white;
                    areauser.GetComponent<UsersMove>().enterEffect.GetComponent<SpriteRenderer>().color = Color.white;
                    areauser.GetComponent<UsersMove>().voiceEffect.GetComponent<SpriteRenderer>().color = Color.white;
                }
                else
                {
                    areauser.GetComponent<SpriteRenderer>().color = new Vector4(0.7f, 0.7f, 0.7f, 1f);
                    areauser.GetComponent<UsersMove>().enterEffect.SetActive(false);
                    areauser.GetComponent<UsersMove>().voiceEffect.SetActive(false);
                }
            }
            else
            {
                areauser.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
            }
        }

    }
    public bool isEnter = false;
    void ExitMaxPOP()
    {
        maxPOP.SetActive(false);
    }
    public bool fullArea = false;

    float t = 0;
    public float delayTime = 0.5f;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AudioZone" && !playerMove.isJumping)//&& area == "" && !isEnter)
        {
            t = 0;

        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AudioZone" && !playerMove.isJumping)//&& area == "" && !isEnter)
        {
            t += Time.deltaTime;
            if (t > delayTime && !isEnter)
            {
                isEnter = true;
                bool mic = webSocketConnect.micState;
                StartCoroutine(GetText(collision.gameObject.name, mic, collision));
                enterEffect.SetActive(true);
            }
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "AudioZone" && !playerMove.isJumping)
        {
            t = 0;
            bool mic = webSocketConnect.micState;
            ExitWebRTC();
            collision.isTrigger = true;
        }
    }
    public void ExitWebRTC()
    {
        if (isEnter)
        {
            MI_Metaverse.ExitRTC(SceneType(), area);
            loadWebRTC = null;
            area = "";
            webSocketConnect.area = "";
            var sprites = GameObject.FindObjectsOfType<SpriteRenderer>();
            var tiles = GameObject.FindObjectsOfType<Tilemap>();
            foreach (var otherSP in sprites)
            {
                otherSP.color = Color.white;
            }
            foreach (var otherTE in tiles)
            {
                otherTE.color = Color.white;
            }
            var IMPASSABLE = GameObject.FindGameObjectWithTag("IMPASSABLE");
            if (IMPASSABLE.GetComponent<Tilemap>())
            {
                IMPASSABLE.GetComponent<Tilemap>().color = new Vector4(0, 0, 0, 0);
            }
            else if (IMPASSABLE.GetComponent<SpriteRenderer>())
            {
                IMPASSABLE.GetComponent<SpriteRenderer>().color = new Vector4(0, 0, 0, 0);
            }
            panel.transform.Find("mic").GetComponent<MicOnOff>().MicState(true);
            panel.transform.Find("mic").gameObject.SetActive(false);
            voiceEffect.SetActive(false);
            enterEffect.SetActive(false);
            isEnter = false;
        }
    }
    string SceneType()
    {
        return webSocketConnect.SceneType();
    }
}
[System.Serializable]
public class EnterData
{
   public string map;
    public string area;
}