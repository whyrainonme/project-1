using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MyDefines.Enum;

public class UIMGR : MonoBehaviour
{
    static UIMGR instance = null;

    GameObject canvas;
    public  PlayerMove playerMove;
    public Camera Maincamera;
    public float cameraSize;

    // Start is called before the first frame update
    void Awake()
    {
        if (instance)
        {
            Destroy(this.gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(this.gameObject);

        Maincamera = Camera.main;
        playerMove = GameObject.Find("Player").GetComponent<PlayerMove>();
    }

    public void Button1()
    {
        switch (playerMove.state)
        {
            case Player_CollisionState.None:
                break;
            case Player_CollisionState.Web:
                Application.OpenURL("http://www.google.com");
                break;
            case Player_CollisionState.Cam:
                canvas.transform.Find("CAM").gameObject.SetActive(true);
                break;
            case Player_CollisionState.SangsangMadang:
                StartCoroutine(LoadScene("SangsangMadang"));
                break;
            case Player_CollisionState.Game1:
                StartCoroutine(LoadScene("Game1"));
                break;
            case Player_CollisionState.Streaming:
                canvas.transform.Find("StreamingPopup");
                break;
        }
    }

    public void LoadSceneSangsangMadang()
    {
        StartCoroutine(LoadScene("SangsangMadang"));
    }

    public IEnumerator LoadScene(string SceneName)
    {
        cameraSize = Maincamera.orthographicSize;
        AsyncOperation async = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(SceneName);

        yield return async;

        if (async.isDone)
        {
            playerMove = GameObject.Find("Player").GetComponent<PlayerMove>();
            Maincamera = GameObject.Find("Main Camera").GetComponent<Camera>();
            Maincamera.orthographicSize = cameraSize;
            if (SceneName == "Game1")
            {
                //�ǹ����ο��� ȫ���Ա��� ������ ����Ǵ� ������ �Ź� �ٲ��� �Ҷ����� ���� ��ġ�� Vector3 �����Ϳ� ������ �� ����ؾ���
                playerMove.gameObject.transform.position = new Vector3(-18f, -4f, -2.7f);
            }
        }
    }
}
