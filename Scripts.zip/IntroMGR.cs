using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class IntroMGR : MonoBehaviour
{
    public GameObject placeUI, avataUI;
    public Transform placeContent;
    public Sprite on, off;
    private void Awake()
    {
        Screen.orientation = ScreenOrientation.Portrait;
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
    }
    public void SceneLoad()
    {
        Screen.orientation = ScreenOrientation.LandscapeLeft;
        //SceneManager.LoadScene("Game1");
        //GameManager.Scene.SceneLoad(MyDefines.Enum.Scene_Type.WolrdMap,"");
    }
    public void AvataLoad()
    {
        placeUI.SetActive(false);
        avataUI.SetActive(true);
    }
    public void StageLoad()
    {
        placeUI.SetActive(true);
    }
    public void SelectPlace()
    {
        for(int i = 0; i < placeContent.childCount; i++)
        {
            placeContent.GetChild(i).GetComponent<Image>().sprite = off;
        }
        EventSystem.current.currentSelectedGameObject.
       gameObject.GetComponent<Image>().sprite = on;
    }
}
