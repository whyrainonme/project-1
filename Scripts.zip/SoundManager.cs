using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    static public SoundManager Instance;
    
    public AudioSource audio;
   // public AudioClip[] BGMList;
    //public AudioClip bgm, effect;
    // Start is called before the first frame update
    void Start()
    {
        if (Instance != null)
        {
            Destroy(this.gameObject);

        }
        else
        {
            DontDestroyOnLoad(this.gameObject);
            Instance = this;
        }
        //bgm = audio.clip;
        //if (!GameManager.Instance.soundData)
        //{
        //    audio.Stop();
        //}
        //else
        //{
        //    audio.Play();
        //}


    }
  
    public void SoundStop()
    {
        audio.Stop();
    }
    public void SoundNonStop()
    {
        audio.Play();
    }
    public void ChangerAudio(int soundNum)
    {
        //audio.clip = BGMList[soundNum];
        if (!GameManager.Instance.soundData)
        {
            audio.Stop();
        }
        else
        {
            audio.Play();
        }
    }
    public AudioClip[] clips;
    public void AudioClipPlay(int num)
    {
        //audio.clip = clips[num];
        audio.PlayOneShot(clips[num], 1f);
    }
    //public void SoundPlay()
    //{
    //    audio.clip = effect;
    //    if (!audio.isPlaying)
    //    {
    //        audio.clip = bgm;
    //        audio.Play();
    //    }
    //}
}
